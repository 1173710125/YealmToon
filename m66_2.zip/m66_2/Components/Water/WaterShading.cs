using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Flags]
public enum DayTimeInterval
{
    None = 0,
    Morning = 1 << 0, // 1
    Noon = 1 << 1, // 2
    Evening = 1 << 2, // 4
    Night = 1 << 3, // 8
    // Continue for additional options
}

[ExecuteAlways]
public class WaterShading : MonoBehaviour
{
    public DayTimeInterval m_dayTimeInterval;
    private const float k_showHideSpeed = 0.03f; // [0, 0.08]

    private MaterialPropertyBlock m_mpb;
    private MeshRenderer m_meshRenderer;

    // Start is called before the first frame update
    void Awake()
    {
        if(Application.isPlaying) Client.Graphic.Misc.DayNightCycleComponent.OnDayTimeUpdateEvent += HandleTimeUpdate;

        m_meshRenderer = GetComponent<MeshRenderer>();
        m_meshRenderer.sharedMaterial.EnableKeyword("_PLANAR_REFLECTION_SSPR");
        m_mpb = new MaterialPropertyBlock();
    }

    void OnDestroy(){
        if(Application.isPlaying) Client.Graphic.Misc.DayNightCycleComponent.OnDayTimeUpdateEvent -= HandleTimeUpdate;
    }

    // Update is called once per frame
    void Update()
    {

    }

    void HandleTimeUpdate(float daytime)
    {
        if(m_meshRenderer == null || m_mpb == null){
            return ;
        }

        float strength = 0.0f;
        float startTime, endTime, startValue, endValue;
        if(daytime < 0.2f || daytime >= 0.867f){
            if(daytime < 0.2f) daytime += 1.0f;
            startTime = 0.867f + k_showHideSpeed;
            startValue = (m_dayTimeInterval & DayTimeInterval.Night) == DayTimeInterval.Night ? 1 : 0;
            endTime = 1.2f - k_showHideSpeed;
            endValue = (m_dayTimeInterval & DayTimeInterval.Morning) == DayTimeInterval.Morning ? 1 : 0;
        }else if(daytime >= 0.2f && daytime < 0.4f){
            startTime = 0.2f + k_showHideSpeed;
            startValue = (m_dayTimeInterval & DayTimeInterval.Morning) == DayTimeInterval.Morning ? 1 : 0;
            endTime = 0.4f - k_showHideSpeed;
            endValue = (m_dayTimeInterval & DayTimeInterval.Noon) == DayTimeInterval.Noon ? 1 : 0;
        }else if(daytime >= 0.4f && daytime < 0.667f){
            startTime = 0.4f + k_showHideSpeed;
            startValue = (m_dayTimeInterval & DayTimeInterval.Noon) == DayTimeInterval.Noon ? 1 : 0;
            endTime = 0.667f - k_showHideSpeed;
            endValue = (m_dayTimeInterval & DayTimeInterval.Evening) == DayTimeInterval.Evening ? 1 : 0;
        }else{
            startTime = 0.667f + k_showHideSpeed;
            startValue = (m_dayTimeInterval & DayTimeInterval.Evening) == DayTimeInterval.Evening ? 1 : 0;
            endTime = 0.867f - k_showHideSpeed;
            endValue = (m_dayTimeInterval & DayTimeInterval.Night) == DayTimeInterval.Night ? 1 : 0;
        }

        daytime = Mathf.Clamp(daytime, startTime, endTime);
        strength = Mathf.Lerp(startValue, endValue, (daytime - startTime) / (endTime - startTime));

        m_meshRenderer.GetPropertyBlock(m_mpb);
        m_mpb.SetFloat("_FakeSunIntensity", strength);
        m_meshRenderer.SetPropertyBlock(m_mpb);
    }
}

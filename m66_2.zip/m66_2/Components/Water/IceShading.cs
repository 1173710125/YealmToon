using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteAlways]
public class IceShading : MonoBehaviour
{
    [Range( 0, 1.0f )]public float m_outRadius; // 外圈半径
    [Range( 0, 0.3f )]public float m_transilationLength;// 外圈半径减去这个，得到内圈半径
    [Range( 0, 0.4f )]public float m_speed;
    public float m_freezeDelayTime;

    private Material m_iceMaterial;
    private int m_textureWidth = 128;
    private int m_textureHeight = 128;
    private Texture2D m_maskTexture;
    private byte[] pixelData;

    // 控制冰开始蔓延的相关参数
    private bool isFreezing = false;
    private Vector2 centerUV = new Vector2(0.5f, 0.5f);

    private float m_timer = 0;

    void Awake()
    {
    }

    void OnDestroy(){
    }

    // Start is called before the first frame update
    void Start()
    {
        if(m_maskTexture == null) m_maskTexture = new Texture2D(m_textureWidth, m_textureHeight, TextureFormat.R8, false);
    
        pixelData = new byte[m_textureWidth * m_textureHeight];
        m_iceMaterial = GetComponent<MeshRenderer>().sharedMaterial;
        m_iceMaterial.EnableKeyword("_PLANAR_REFLECTION_SSPR");
    }

    // Update is called once per frame
    void Update()
    {
        if(isFreezing)
        {
            m_timer += Time.deltaTime * m_speed;
            if(m_timer > 1.5f) isFreezing = false;
            m_outRadius = m_timer;
        }



        for(int x = 0; x < m_textureWidth; x++)
        {
            for(int y = 0; y < m_textureHeight; y++)
            {
                float nx = (x + 0.5f) / m_textureWidth;
                float ny = (y + 0.5f) / m_textureHeight;

                float dx = nx - centerUV.x;
                float dy = ny - centerUV.y;
                float distance = Mathf.Sqrt(dx * dx + dy * dy);

                float value = Mathf.Lerp(0, 1, (m_outRadius - distance) / (m_transilationLength));
                byte intensity = (byte)(Mathf.Clamp01(value) * 255);

                pixelData[y * m_textureWidth + x] = intensity;
            }
        }

        m_maskTexture.SetPixelData(pixelData, 0);
        m_maskTexture.Apply();

        m_iceMaterial.SetTexture("_MaskMap", m_maskTexture);
    }

    // 根据人物坐标，释放冻结技能后 冻结整个冰面
    public void IceFreeze(GameObject character)
    {
        // 定义射线，起点是角色的位置，方向是 Vector3.down（向下）
        RaycastHit[] hits = Physics.RaycastAll(character.transform.position + new Vector3(0, 1, 0), Vector3.down, Mathf.Infinity);

        // 投射射线，最大距离可以根据需要调整
        foreach (var hit in hits)
        {
            if (hit.collider.CompareTag("Ice"))
            {
                // 获取地面UV坐标
                Vector2 uv = hit.textureCoord;

                centerUV = uv;
                Invoke("StartFreezing", m_freezeDelayTime);

                // 输出UV坐标
                Debug.Log("UV Coordinates: " + uv);
            }
        }

    }

    // 测试用 重置冰面
    public void ResetFreeze()
    {
        m_timer = 0f;
        isFreezing = false;
        m_outRadius = 0f;
    }

    private void StartFreezing()
    {
        isFreezing = true;
    }

}

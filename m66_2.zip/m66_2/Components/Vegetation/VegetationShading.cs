using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteAlways]
public class VegetationShading : MonoBehaviour
{
    Material m_vegetationMaterial;
    Mesh m_vegetationMesh;

    // Start is called before the first frame update
    void Start()
    {
        m_vegetationMaterial = GetComponent<Renderer>().sharedMaterial;
        m_vegetationMesh = GetComponent<MeshFilter>().sharedMesh;
        UpdateVegetationInformation();
    }

    // Update is called once per frame
    void Update()
    {
        if(!Application.isPlaying){
            UpdateVegetationInformation();
        }
    }

    private void OnValidate()
    {
        UpdateVegetationInformation();
    }

    private void UpdateVegetationInformation()
    {
        if(m_vegetationMaterial == null || m_vegetationMesh == null){
            return ;
        }

        m_vegetationMaterial.SetFloat("_VegetationHeightMin", m_vegetationMesh.bounds.min.y);
        m_vegetationMaterial.SetFloat("_VegetationHeightMax", m_vegetationMesh.bounds.max.y);
    }
}

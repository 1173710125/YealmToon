using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 用于在游戏进行时，动态创建并设置新的material
public class FastTerrainInitial : MonoBehaviour
{
    public Material editorMaterial; // 原始刷子的material
    private Texture2D splatID; // 索引贴图

    private Material fastMeshMaterial;
    private Texture2DArray albedoTexArray;
    private Texture2DArray normalTexArray;
    private Texture2DArray informationTexArray;
    private Texture2DArray splatWeightTexArray;
    private static readonly int splatNum = 8;

    struct SplatData
    {
        public int id;
        public float weight;
        public float nearWeight;
    }

    private void OnEnable()
    {
        Debug.LogWarning("fast terrain enable");

        // 1: 生成texture array
        GenerateTextureArray();

        // 2：生成material
        fastMeshMaterial = new Material(Shader.Find("M66-2/Scene/Terrain/FastMesh"));
        this.GetComponent<UnityEngine.Renderer>().sharedMaterial = fastMeshMaterial;
        for (int i = 0; i < transform.childCount; i++)
        {
            GameObject child = transform.GetChild(i).gameObject;
            if(child.name.Contains("SubMesh")){
                child.GetComponent<UnityEngine.Renderer>().sharedMaterial = fastMeshMaterial;
            }
        }
        fastMeshMaterial.EnableKeyword("_APPLY_WEATHER");

        // 3：设置material参数
        SetMaterialPara();
    }

    private void OnDisable() {
        Debug.LogWarning("fast terrain disable");
        this.GetComponent<UnityEngine.Renderer>().sharedMaterial = editorMaterial;
        for (int i = 0; i < transform.childCount; i++)
        {
            GameObject child = transform.GetChild(i).gameObject;
            if(child.name.Contains("SubMesh")){
                child.GetComponent<UnityEngine.Renderer>().sharedMaterial = editorMaterial;
            }
        }
    }

    private void GenerateTextureArray()
    {
        for(int i=0; i<splatNum; i++)
        {
            Texture2D texAlbedo = (Texture2D)editorMaterial.GetTexture("_Splat" + (i+1));
            Texture2D texNormal = (Texture2D)editorMaterial.GetTexture("_Splat" + (i+1) + "N");
            Texture2D texInformation = (Texture2D)editorMaterial.GetTexture("_Splat" + (i+1) + "B");

            if(i == 0){
                int wid = texAlbedo.width;
                int hei = texAlbedo.height;

                int widNormal = texNormal.width;
                int heiNormal = texNormal.height;

                int widInformation = texInformation.width;
                int heiInformation = texInformation.height;

                // 点过滤
                albedoTexArray = new Texture2DArray(wid, hei, splatNum, texAlbedo.format, true,false);
                normalTexArray = new Texture2DArray(widNormal, heiNormal, splatNum, texNormal.format, true, true);  //是否为线性纹理
                informationTexArray = new Texture2DArray(widInformation, heiInformation, splatNum, texInformation.format, true, false);  //临时改为非线性，以后一定要改回来哦~~~~~~
            }

            // if (i >= normalTerrainData.terrainLayers.Length) break; 
            for (int k = 0; k < texAlbedo.mipmapCount; k++)
            {
                Graphics.CopyTexture(texAlbedo, 0, k, albedoTexArray, i, k);
            }
            for (int k = 0; k < texNormal.mipmapCount; k++)
            {
                Graphics.CopyTexture(texNormal, 0, k, normalTexArray, i, k);
            }
            for (int k = 0; k < texInformation.mipmapCount; k++)
            {
                Graphics.CopyTexture(texInformation, 0, k, informationTexArray, i, k);
            }
        }



        List<Color[]> colors = new List<Color[]>();
        int ControlWid = 0;
        int ControlHei = 0;
        //t.terrainData.alphamapTextures[i].GetPixels();
        for (int i = 0; i < splatNum / 4; i++)
        {
            Texture2D splatWeightTex = (Texture2D)editorMaterial.GetTexture("_Control" + (i+1));

            if(i == 0){
                ControlWid = splatWeightTex.width;
                ControlHei = splatWeightTex.height;

                splatID = new Texture2D(ControlWid, ControlHei, TextureFormat.RGB24, false, true);
                splatID.filterMode = FilterMode.Point;

                splatWeightTexArray = new Texture2DArray(ControlWid, ControlHei, splatNum / 4, splatWeightTex.format, true, true);
                splatWeightTexArray.filterMode = FilterMode.Bilinear;
            }

            colors.Add(splatWeightTex.GetPixels());
            splatWeightTexArray.SetPixels(splatWeightTex.GetPixels(), i);
        }
        splatWeightTexArray.Apply();


        var splatIDColors = splatID.GetPixels();

        for (int i = 0; i < ControlHei; i++)
        {
            for (int j = 0; j < ControlWid; j++)
            {
                List<SplatData> splatDatas = new List<SplatData>();
                int index = i * ControlWid + j;
                // splatIDColors[index].r=1 / 16.0f;
                //struct 是值引用 所以 Add到list后  可以复用（修改他属性不会影响已经加入的数据）
                for (int k = 0; k < colors.Count; k++)
                {
                    SplatData sd;
                    sd.id = k * 4;
                    sd.weight = colors[k][index].r;
                    sd.nearWeight = getNearWeight(colors[k], index, ControlWid, 0);
                    splatDatas.Add(sd);

                    sd.id++;
                    sd.weight = colors[k][index].g;
                    sd.nearWeight = getNearWeight(colors[k], index, ControlWid, 1);

                    splatDatas.Add(sd);
                    sd.id++;
                    sd.weight = colors[k][index].b;
                    sd.nearWeight = getNearWeight(colors[k], index, ControlWid, 2);

                    splatDatas.Add(sd);
                    sd.id++;
                    sd.weight = colors[k][index].a;
                    sd.nearWeight = getNearWeight(colors[k], index, ControlWid, 3);

                    splatDatas.Add(sd);
                }

            
                //按权重排序选出最重要几个
                splatDatas.Sort((x, y) => -(x.weight+x.nearWeight).CompareTo(y.weight+y.nearWeight));
                

                //只存最重要3个图层 用一点压缩方案可以一张图存更多图层 ,这里最多支持16张
                splatIDColors[index].r = splatDatas[0].id / 16f; //
                splatIDColors[index].g = splatDatas[1].id / 16f;
                splatIDColors[index].b =  splatDatas[2].id / 16f;

            }
        }

        splatID.SetPixels(splatIDColors);
        splatID.Apply();
    }

    private void SetMaterialPara()
    {
        // texture
        fastMeshMaterial.SetTexture("_SplatIDTex", splatID);
        fastMeshMaterial.SetTexture("_SplatWeightTexArray", splatWeightTexArray);
        fastMeshMaterial.SetTexture("_AlbedoTexArray", albedoTexArray);
        fastMeshMaterial.SetTexture("_NormalTexArray", normalTexArray);
        fastMeshMaterial.SetTexture("_MixedTexArray", informationTexArray);

        // 法线强度， Tilling， _BlendHeightTransition;
        List<Vector4> splatTillingAndNormalScale = new List<Vector4>();
        
        for(int i = 0; i < splatNum; i++){
            Vector4 tilling = editorMaterial.GetVector("_Splat" + (i+1) + "_ST");
            float normalScale = editorMaterial.GetFloat("_Splat" + (i+1) + "NScale");
            Vector4 temp = new Vector4(tilling.x, tilling.y, normalScale, 0.0f);
            splatTillingAndNormalScale.Add(temp);
        }
        float heightTransition = editorMaterial.GetFloat("_BlendHeightTransition");


        fastMeshMaterial.SetVectorArray("_SplatTillingAndNormalScale", splatTillingAndNormalScale);
        fastMeshMaterial.SetFloat("_BlendHeightTransition", heightTransition);

        // 地形的render queue设置为2010（在一般不透明物体之后）
        fastMeshMaterial.renderQueue = 2010;
    }

    private float getNearWeight(Color[] colors, int index, int wid, int rgba)
    {
        float value = 0;
        for (int i = 1; i <= 2; i++)
        {
            value += colors[(index + colors.Length - i) % colors.Length][rgba];
            value += colors[(index + colors.Length + i) % colors.Length][rgba];
            value += colors[(index + colors.Length - wid * i) % colors.Length][rgba];
            value += colors[(index + colors.Length + wid * i) % colors.Length][rgba];
            value += colors[(index + colors.Length + (-1 - wid) * i) % colors.Length][rgba];
            value += colors[(index + colors.Length + (-1 + wid) * i) % colors.Length][rgba];
            value += colors[(index + colors.Length + (1 - wid) * i) % colors.Length][rgba];
            value += colors[(index + colors.Length + (1 + wid) * i) % colors.Length][rgba];
        }

        return value / (8 * 2);
    }
}

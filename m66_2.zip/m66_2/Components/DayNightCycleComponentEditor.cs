using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using Client.Graphic.Misc;

namespace Client.Editor.Graphic
{
    [CustomEditor(typeof(DayNightCycleComponent))]
    public class DayNightCycleComponentEditor : UnityEditor.Editor
    {
        public GUISkin buttonSkin;
        protected int _currentTab = 0;
        protected int _modeTab = 0; // 0:editor mode  1:preview mode

        private float m_animationTime;

        void OnEnable()
        {
            EditorApplication.update += OnUpdate;
        }

        private void OnDisable()
        {
            EditorApplication.update -= OnUpdate;
        }

        void OnUpdate()
        {
            if (!EditorApplication.isPlaying && AnimationMode.InAnimationMode() && _modeTab == 1)
            {
                DayNightCycleComponent cop = (DayNightCycleComponent)target;
                List<AnimatorAndClip> animatorAndClips = cop.m_animatorAndClips;

                AnimationMode.BeginSampling();
                foreach(AnimatorAndClip animatorAndClip in animatorAndClips){
                    AnimationMode.SampleAnimationClip(animatorAndClip.animator.gameObject, animatorAndClip.clip, m_animationTime);
                }
                AnimationMode.EndSampling();

                SceneView.RepaintAll();
            }
        }

        public override void OnInspectorGUI()
        {
            // // 更新 SerializedObject
            // serializedObject.Update();

            // // 显示其它属性或自定义 GUI 元素
            // DrawDefaultInspector();

            // // 应用属性修改
            // serializedObject.ApplyModifiedProperties();

            GUI.color = EditorGUIUtility.isProSkin ? new Color( 0.1f, 0.1f, 0.15f, 1 ) : new Color( 0.5f, 0.5f, 0.6f );
            GUILayout.BeginVertical( EditorStyles.helpBox );
            GUI.color = Color.white;

            GUILayout.BeginHorizontal();
            GUILayout.Space( 12 );
            if ( GUILayout.Button( "editor模式", _modeTab == 0 ? buttonSkin.customStyles[6] : buttonSkin.customStyles[5], GUILayout.MaxWidth(240) ) ) {
                _modeTab = 0;
            }

            GUILayout.Space( 12 );
            if ( GUILayout.Button( "预览模式", _modeTab == 1 ? buttonSkin.customStyles[6] : buttonSkin.customStyles[5], GUILayout.MaxWidth(240) ) ) {
                _modeTab = 1;

            }

            GUILayout.Space( 12 );
            GUILayout.EndHorizontal();

            GUILayout.BeginVertical();
            if(_modeTab == 0){
                GUILayout.Space( 16 );
                CenteredLabel("editor模式");
                GUILayout.Space( 16 );

                AnimationMode.StopAnimationMode();
            }else if(_modeTab == 1){
                GUILayout.Space( 16 );
                CenteredLabel("预览模式");
                GUILayout.Space( 16 );

                GUILayout.Label("温馨提示，清晨为0.25，中午为0.5，黄昏为0.8333，夜晚为1.0833");

                // 选择预览时间
                AnimationMode.StartAnimationMode();

                float startTime = 0.0f;
                float stopTime  = 1.25f;
                m_animationTime = EditorGUILayout.Slider(m_animationTime, startTime, stopTime);
            }
            GUILayout.EndVertical();

            GUILayout.Space( 8 );

            GUILayout.BeginHorizontal();

            GUILayout.Space(16);

            if ( GUILayout.Button( "General Settings", _currentTab == 0 ? buttonSkin.customStyles[6] : buttonSkin.customStyles[5], GUILayout.MaxWidth(240) ) ) {
                _currentTab = 0;
            }

            GUILayout.Space( 12 );

            if ( GUILayout.Button( "light", _currentTab == 1?buttonSkin.customStyles[6]:buttonSkin.customStyles[5], GUILayout.MaxWidth(240) ) ) {
                _currentTab = 1;
            }
        
            GUILayout.Space( 12 );

            if ( GUILayout.Button( "skybox & cloud", _currentTab == 2 ? buttonSkin.customStyles[6] : buttonSkin.customStyles[5], GUILayout.MaxWidth( 240 ) ) ) {
                _currentTab = 2;
            }

            GUILayout.Space( 12 );

            if ( GUILayout.Button( "others", _currentTab == 3 ? buttonSkin.customStyles[6] : buttonSkin.customStyles[5], GUILayout.MaxWidth( 240 ) ) ) {
                _currentTab = 3;
            }
        

            GUILayout.Space(16);
            GUILayout.EndHorizontal();

            GUILayout.Space(8);

            GUILayout.BeginHorizontal(); GUILayout.Space( 16 );

            if ( GUILayout.Button( "fog", _currentTab == 4?buttonSkin.customStyles[6]:buttonSkin.customStyles[5], GUILayout.MaxWidth(240) ) ) {
                _currentTab = 4;
            }

            GUILayout.Space( 12 );

            if ( GUILayout.Button( "wind", _currentTab == 5?buttonSkin.customStyles[6]:buttonSkin.customStyles[5], GUILayout.MaxWidth(240) ) ) {
                _currentTab = 5;
            }

            GUILayout.Space( 12 );

            if ( GUILayout.Button( "weather", _currentTab == 6?buttonSkin.customStyles[6]:buttonSkin.customStyles[5], GUILayout.MaxWidth(240) ) ) {
                _currentTab = 6;
            }

            GUILayout.Space(16);
            GUILayout.EndHorizontal();


            GUILayout.BeginHorizontal(); GUILayout.Space( 16 );

            GUILayout.BeginVertical();
            if ( _currentTab == 0 ) {
                GUILayout.Space( 16 );
                CenteredLabel( "引用" );
                GUILayout.Space( 16 );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_timeOfDayDirector"), new GUIContent( "timeline引用" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_mainLight"), new GUIContent( "主平行光源" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_skyboxMat"), new GUIContent( "天空盒材质球" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_skyCloudMat"), new GUIContent( "云材质球" ) );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("switchTimes"), new GUIContent( "时间节点设置" ) );
            }

            if ( _currentTab == 1 ) {
                GUILayout.Space( 16 );
                CenteredLabel( "光照" );
                GUILayout.Space( 16 );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_intensity"), new GUIContent( "平行光强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_mainColor"), new GUIContent( "平行光颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_shadowAtten"), new GUIContent( "平行光阴影强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_cloudShadowAtten"), new GUIContent( "云阴影强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_shadowColor"), new GUIContent( "阴影颜色" ) );

                GUILayout.Space( 16 );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_emissionIntensity"), new GUIContent( "自发光强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_bakeLightIntensity"), new GUIContent( "烘焙光强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_additionLightIntensity"), new GUIContent( "额外光强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_planarReflectionStrength"), new GUIContent( "平面反射光照强度" ) );

                GUILayout.Space( 16 );
                
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_environmentIntensity"), new GUIContent( "环境光强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_upPartSkyColor"), new GUIContent( "上半部分环境光颜色（同时影响天空盒）" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_downPartSkyColor"), new GUIContent( "地平线部分环境光颜色（同时影响天空盒）" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_undergroundPartSkyColor"), new GUIContent( "下半部分环境光颜色" ) );

                GUILayout.Space( 16 );
                
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_volumetricLightIntensity"), new GUIContent( "默认体积光强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_individualVolumetricLights"), new GUIContent( "特殊体积光（不随默认体积光强度变化）" ) );
                


            }
            
            if ( _currentTab == 2 ) {
                GUILayout.Space( 16 );
                CenteredLabel( "天空盒 & 云 " );
                GUILayout.Space( 16 );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_upPartSunColor"), new GUIContent( "上半部分太阳颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_downPartSunColor"), new GUIContent( "地平线部分太阳颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_mainColorSunGatherFactor"), new GUIContent( "太阳颜色影响范围" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_irradianceMapR_range"), new GUIContent( "irradianceMapR_range" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_sunAdditionColor"), new GUIContent( "太阳额外颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_sunAdditionIntensity"), new GUIContent( "太阳额外颜色强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_irradianceMapG_maxAngleRange"), new GUIContent( "irradianceMapG_maxAngleRange" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_sun_disk_power_999"), new GUIContent( "太阳圆盘大小" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_sun_color"), new GUIContent( "太阳圆盘颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_sun_color_intensity"), new GUIContent( "太阳圆盘颜色强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_sun_shine_color"), new GUIContent( "太阳shine颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_sunTransmission"), new GUIContent( "sunTransmission" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_transmissionLDotVStartAt"), new GUIContent( "transmissionLDotVStartAt" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_starColorIntensity"), new GUIContent( "星星颜色强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_starOcclusion"), new GUIContent( "星星数量遮蔽" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_starNoiseSpeed"), new GUIContent( "星星闪烁频率" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_cloudColor_Bright_Center"), new GUIContent( "云亮部中心颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_cloudColor_Bright_Around"), new GUIContent( "云亮部周边颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_cloudColor_Dark_Center"), new GUIContent( "云暗部中心颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_cloudColor_Dark_Around"), new GUIContent( "云暗部周围颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_cloudTransparency"), new GUIContent( "云透明度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_lDotV_damping_factor_cloud"), new GUIContent( "m_lDotV_damping_factor_cloud" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_cloudMoreBright"), new GUIContent( "云增亮" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_disturbanceNoiseOffset"), new GUIContent( "m_disturbanceNoiseOffset" ) );
            }

            if ( _currentTab == 3 ) {
                GUILayout.Space( 16 );
                CenteredLabel( "杂项" );
                GUILayout.Space( 16 );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_flockController"), new GUIContent( "鸟群特效引用" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_kunchongFX"), new GUIContent( "昆虫特效引用" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_birdsNumber"), new GUIContent( "鸟数量" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_mothsVFXOpen"), new GUIContent( "蚊虫特效开关" ) );
            }

            if ( _currentTab == 4 ) {
                GUILayout.Space( 16 );
                CenteredLabel( "雾" );
                GUILayout.Space( 16 );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_fogHeightFalloff"), new GUIContent( "雾高度衰减" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_fogStartDistance"), new GUIContent( "雾起始距离" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_fogDensity"), new GUIContent( "雾强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_fogHeight"), new GUIContent( "雾高度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_fogColor"), new GUIContent( "雾颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_directionalInscatteringColor"), new GUIContent( "方向光散射颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_inscaterringExponent"), new GUIContent( "散射强度" ) );
            }

            if ( _currentTab == 5 ) {
                GUILayout.Space( 16 );
                CenteredLabel( "风" );
                GUILayout.Space( 16 );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_windDirection"), new GUIContent( "风向" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_windIntensity"), new GUIContent( "风强度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_turbulence"), new GUIContent( "turbulence" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_noiseFrequency"), new GUIContent( "摇摆频率" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_noiseScale"), new GUIContent( "noise scale" ) );

            }

            if ( _currentTab == 6 ) {
                GUILayout.Space( 16 );
                CenteredLabel( "天气" );
                GUILayout.Space( 16 );

                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_humidity"), new GUIContent( "潮湿度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_waterColor"), new GUIContent( "积水颜色" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_rainNoiseMap"), new GUIContent( "积水noise" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_rainNoiseContrast"), new GUIContent( "积水noise对比度" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_rainNoiseTillingOffset"), new GUIContent( "积水noise贴图tilling & offset" ) );
                EditorGUILayout.PropertyField( serializedObject.FindProperty("m_rainFXs"), new GUIContent( "雨特效引用" ) );
                
            }

            GUILayout.EndVertical(); 

            GUILayout.Space( 16 ); GUILayout.EndHorizontal();

            GUILayout.EndVertical();

            serializedObject.ApplyModifiedProperties();

        }


        void CenteredLabel( string label ) {

            
            GUILayout.BeginHorizontal(); GUILayout.FlexibleSpace();

            var tempStyle = new GUIStyle();
            tempStyle.fontStyle = FontStyle.Bold;
            tempStyle.normal.textColor = EditorGUIUtility.isProSkin?Color.white:Color.black;

            GUILayout.Label( label, tempStyle );

            GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();

        }
    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using Client.Graphic.Misc;

public class VolumesManager : MonoBehaviour
{
    public static VolumesManager Instance;
    
    // public Volume SceneVolume;
    public Volume SceneVolume;

    //uivolume 暂时留空
    
    // volumeComponent
    private GlobalParameterSettings m_globalParameterSettings;

    // connect compoent Ref

    private void Awake()
    {
        Instance = this;
    }

    private void OnEnable() 
    {
        GetGlobalParameterSettings(); 
    }

    // ---------------------------------------------------------------------------------------------------- get
    public VolumeComponent GetGlobalParameterSettings()
    {
        if (m_globalParameterSettings == null)
            SceneVolume.profile.TryGet<GlobalParameterSettings>(out m_globalParameterSettings);
            
        return m_globalParameterSettings;
    }

    // ---------------------------------------------------------------------------------------------------- set

    public static void SetSceneVolumeProfile(string path)
    {
        VolumeProfile profile = (VolumeProfile)JSZXResource.Runtime.ResourceManager.LoadAsset(path).asset;
        ClearSceneVolumeComponentRef();
        Instance.SceneVolume.profile = profile;
    }

    // public static void SetSceneVolumeProfile(string path)
    // {
    //     VolumeProfile profile = (VolumeProfile)JSZXResource.Runtime.ResourceManager.LoadAsset(path).asset;

    //     Instance.SceneVolume.profile = profile;
    // }

    public static void ClearSceneVolumeComponentRef() 
    {
        Instance.m_globalParameterSettings = null;
    }

}

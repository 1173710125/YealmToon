using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Playables;
using UnityEngine.Timeline;
using VolumetricLights;

namespace Client.Graphic.Misc
{
    public class AnimatorAndClip
    {
        public Animator animator;
        public AnimationClip clip;
        public int clipHash;
    }


    [ExecuteAlways]
    [System.Serializable]
    public class DayNightCycleComponent : MonoBehaviour
    {
        public static event Action<float> OnDayTimeUpdateEvent;

        public PlayableDirector m_timeOfDayDirector;
        public List<AnimatorAndClip> m_animatorAndClips = new List<AnimatorAndClip>();

        //平行光
        public Light m_mainLight;
        public float m_intensity;
        public Color m_mainColor;
        [Range( 0, 1 )]public float m_shadowAtten;
        [Range( 0, 1 )]public float m_cloudShadowAtten;
        [ColorUsage(true, true)]
        public Color m_shadowColor;

        //自发光
        public float m_emissionIntensity;

        //烘焙光强度
        public float m_bakeLightIntensity;

        //额外光
        public float m_additionLightIntensity;

        // 环境光
        public float m_environmentIntensity;

        // 体积光
        public float m_volumetricLightIntensity;
        public VolumetricLight[] m_individualVolumetricLights;
        private MaterialPropertyBlock m_volumetricLightBlock;

        // 反射相关
        [Range( 0, 0.5f )]public float m_planarReflectionStrength;

        // 天空盒参数
        public Material m_skyboxMat;
        public Material m_skyCloudMat;
        public Color m_upPartSunColor; 
        public Color m_upPartSkyColor;  //同时用于环境光
        public Color m_downPartSunColor;
        public Color m_downPartSkyColor;    //同时用于环境光
        public Color m_undergroundPartSkyColor;
        [Range( 0, 1 )]public float m_mainColorSunGatherFactor;
        [Range( 0, 1 )]public float m_irradianceMapR_range;

        [Range( 0, 20 )]public float m_starColorIntensity;
        [Range( 0, 1 )]public float m_starOcclusion;
        [Range( 0, 1 )]public float m_starNoiseSpeed;

        public Color m_sunAdditionColor;
        [Range( 0, 2 )]public float m_sunAdditionIntensity;
        [Range( 0, 1 )]public float m_irradianceMapG_maxAngleRange;
        [Range( 0, 1000 )]public float m_sun_disk_power_999;
        public Color m_sun_color;
        [Range( 0, 10 )]public float m_sun_color_intensity;
        public Color m_sun_shine_color;
        [Range( 0, 10 )]public float m_sunTransmission;
        [Range( 0, 1 )]public float m_transmissionLDotVStartAt;
        public Color m_cloudColor_Bright_Center;
        public Color m_cloudColor_Bright_Around;
        public Color m_cloudColor_Dark_Center;
        public Color m_cloudColor_Dark_Around;
        [Range( 0, 1 )]public float m_cloudTransparency = 1.0f;
        public float m_lDotV_damping_factor_cloud;
        [Range( 0, 5 )]public float m_cloudMoreBright;
        public float m_disturbanceNoiseOffset;


        // 雾效参数
        [Range( 0, 0.1f )]public float m_fogHeightFalloff;
        public float m_fogStartDistance;
        [Range( 0, 0.3f )]public float m_fogDensity;
        public float m_fogHeight;
        public Color m_fogColor;
        public Color m_directionalInscatteringColor;
        public float m_inscaterringExponent;

        // 风参数
        public Vector3 m_windDirection;
        public float m_windIntensity;
        public float m_turbulence;
        public float m_noiseFrequency;
        public float m_noiseScale;

        // 天气相关参数
        [Range( 0, 1 )]public float m_humidity;
        [Range( 0.1f, 10 )]public float m_rainNoiseContrast = 1.0f;
        public Color m_waterColor;
        public Vector4 m_rainNoiseTillingOffset;
        public Texture m_rainNoiseMap;

        // 杂项
        public FlockController m_flockController;
        public GameObject m_kunchongFX;
        public int m_birdsNumber;
        public bool m_mothsVFXOpen;


        // 雨
        public ParticleSystem[] m_rainFXs;
        private List<float> m_defaultRainFXRateOverTime = new List<float>();


        private float m_dayTime;
        public float[] switchTimes = new float[3]{0.4f, 0.667f, 0.867f}; // 0.2f 清晨 会被掠过，但需要K
        private int currentTimeIndex;
        private int targetTimeIndex;
        private int currentDay = 0;
        private bool updateDaynightParaFlag = true;
        private int dnCycleHash;
        private int FXCycleHash;
        // 声音管理器
        private AudioManager audioManager;

        public void Awake()
        {
            currentTimeIndex = 1;
            targetTimeIndex = 1;

            // 获取所有动画animator和clip方便后面处理
            foreach (var track in m_timeOfDayDirector.playableAsset.outputs)
            {
                AnimatorAndClip animatorAndClip = new AnimatorAndClip();

                // 检查轨道是否为AnimationTrack类型
                if (track.sourceObject is AnimationTrack animationTrack)
                {
                    // 获取绑定对象
                    var binding = m_timeOfDayDirector.GetGenericBinding(track.sourceObject);

                    // 判断绑定对象是否为Animator
                    if (binding is Animator animator)
                    {
                        animator.speed = 0;
                        animatorAndClip.animator = animator;
                    }

                    // 获取该轨道上的所有Clip
                    foreach (var clip in animationTrack.GetClips())
                    {
                        if (clip.asset is AnimationPlayableAsset animationPlayableAsset && animationPlayableAsset.clip != null)
                        {
                            animatorAndClip.clip = animationPlayableAsset.clip;
                            animatorAndClip.clipHash = Animator.StringToHash(animatorAndClip.clip.name);
                        }
                    }
                    m_animatorAndClips.Add(animatorAndClip);
                }

                
            }
        }

        private void Start()
        {
            if (Application.isPlaying)
            {
                //初始时间
                SetDayTime(switchTimes[currentTimeIndex]);
            }

            foreach(ParticleSystem sys in m_rainFXs){
                m_defaultRainFXRateOverTime.Add(sys.emission.rateOverTimeMultiplier);
            }

            // 不在数组内的体积光，keyword设置为false
            Shader.SetGlobalFloat("_IsIndividualLight", 0f);
        }

        private void OnEnable() 
        {
            audioManager = gameObject.GetComponent<AudioManager>();

            if(Application.isPlaying)
                UpdateAudio(currentTimeIndex);
        }


        public void Update()
        {
            //Debug.LogWarning("wanym" + m_dayTime + "::" + currentTimeIndex + "::" + targetTimeIndex);
            if (currentTimeIndex != targetTimeIndex){
                m_dayTime += Time.deltaTime / 6.0f;
                m_dayTime -= (int)m_dayTime;
                SetDayTime(m_dayTime);
            } 
            if (m_dayTime - switchTimes[targetTimeIndex] < 0.02f && m_dayTime > switchTimes[targetTimeIndex]){
                currentTimeIndex = targetTimeIndex; 
            }

            // 临时代码，响应键盘按键
            if (Input.GetKeyDown(KeyCode.T))
            {
                SwitchDayTime();
            }
        }

        public void LateUpdate()
        {
            if(updateDaynightParaFlag){
                updateDaynightPara();
                updateDaynightParaFlag = false;
            }

            #if UNITY_EDITOR
                //游戏不在运行状态下时
                if(!Application.isPlaying){
                    updateDaynightPara();
                }
            #endif 
        }

        // dayTime[0, 1]
        // 约定：游戏运行状态下，脚本控制时间的唯一接口，同步更新光照与天空盒信息
        public void SetDayTime(float dayTime)
        {
            m_dayTime = dayTime - (int)dayTime;//根据time设置timeline时间
            // m_timeOfDayDirector.time = m_dayTime;
            // m_timeOfDayDirector.Evaluate(); // 强制Timeline更新到目标时间点
            foreach(AnimatorAndClip animatorAndClip in m_animatorAndClips)
            {
                animatorAndClip.animator.Play(animatorAndClip.clipHash, -1, m_dayTime);
            }
            // m_timeOfDayDirector.Pause();

            //根据参数更新光照与天空盒信息
            //animator.Play执行完参数修改后当帧已结束？所以给下一帧执行
            updateDaynightParaFlag = true;

            // 发送事件，更新时间
            OnDayTimeUpdateEvent?.Invoke(m_dayTime);
        }

        public void SwitchDayTime(){
            targetTimeIndex++;
            if(targetTimeIndex == 1){
                currentDay++;
            }
            targetTimeIndex %= switchTimes.Length;

            UpdateAudio(targetTimeIndex);
        }

        private void updateDaynightPara(){
            UpdateLight();
            UpdateSkybox();
            UpdateFog();
            UpdateWind();
            UpdateWeather();
            UpdateOthers();
        }


        private void UpdateLight()
        {
            m_mainLight.intensity = m_intensity;
            m_mainLight.color = m_mainColor;
            m_mainLight.shadowStrength = m_shadowAtten;

            // 额外光照强度
            Shader.SetGlobalFloat("_AdditionLightIntensity", m_additionLightIntensity);

            // 自发光强度
            Shader.SetGlobalFloat("_EmissionIntensity", m_emissionIntensity);

            // 环境光 (分为 上 赤道 下 三个部分颜色 插值得到环境光)
            // _UpPartSkyColor 与 _middlePartSkyColor 同时影响到skybox渲染
            Shader.SetGlobalColor("_UpPartSkyColor", m_upPartSkyColor * m_environmentIntensity);
            Shader.SetGlobalColor("_DownPartSkyColor", m_downPartSkyColor * m_environmentIntensity);
            Shader.SetGlobalColor("_UndergroundPartSkyColor", m_undergroundPartSkyColor * m_environmentIntensity);
            Shader.SetGlobalFloat("_BakeLightIntensity", m_bakeLightIntensity);
            Shader.SetGlobalFloat("_CloudShadowAtten", m_cloudShadowAtten);
            Shader.SetGlobalFloat("_VolumetricLightIntensity", m_volumetricLightIntensity);
            Shader.SetGlobalFloat("_RefStrength", m_planarReflectionStrength);

            foreach(VolumetricLight light in m_individualVolumetricLights){
                if(light == null) continue;
                Renderer rend = light.gameObject.GetComponent<Renderer>();
                if(m_volumetricLightBlock == null){
                    m_volumetricLightBlock = new MaterialPropertyBlock();
                }
                m_volumetricLightBlock.SetFloat("_IsIndividualLight", 1.0f);
                rend.SetPropertyBlock(m_volumetricLightBlock);
            }

            // 阴影颜色，同时影响到云阴影颜色和平行光阴影部分颜色
            Shader.SetGlobalColor("_ShadowColor", m_shadowColor);
        }

        private void UpdateSkybox()
        {
            // 天空盒子            
            m_skyboxMat.SetColor("_upPartSunColor", m_upPartSunColor);
            m_skyboxMat.SetColor("_UpPartSkyColor", m_upPartSkyColor);
            m_skyboxMat.SetColor("_downPartSunColor", m_downPartSunColor);
            m_skyboxMat.SetColor("_DownPartSkyColor", m_downPartSkyColor);
            m_skyboxMat.SetFloat("_mainColorSunGatherFactor", m_mainColorSunGatherFactor);
            m_skyboxMat.SetFloat("_IrradianceMapR_maxAngleRange", m_irradianceMapR_range);
            m_skyboxMat.SetFloat("_starColorIntensity", m_starColorIntensity);
            m_skyboxMat.SetFloat("_starIntensityLinearDamping", m_starOcclusion);
            m_skyboxMat.SetFloat("_NoiseSpeed", m_starNoiseSpeed);

            m_skyboxMat.SetColor("_sunAdditionColor", m_sunAdditionColor);
            m_skyboxMat.SetFloat("_sunAdditionIntensity", m_sunAdditionIntensity);
            m_skyboxMat.SetFloat("_irradianceMapG_maxAngleRange", m_irradianceMapG_maxAngleRange);
            m_skyboxMat.SetFloat("_sun_disk_power_999", m_sun_disk_power_999);
            m_skyboxMat.SetColor("_sun_color", m_sun_color);
            m_skyboxMat.SetFloat("_sun_color_intensity", m_sun_color_intensity);

            // 云
            m_skyCloudMat.SetColor("_upPartSunColor", m_upPartSunColor);
            m_skyCloudMat.SetColor("_UpPartSkyColor", m_upPartSkyColor);
            m_skyCloudMat.SetColor("_downPartSunColor", m_downPartSunColor);
            m_skyCloudMat.SetColor("_DownPartSkyColor", m_downPartSkyColor);
            m_skyCloudMat.SetFloat("_mainColorSunGatherFactor", m_mainColorSunGatherFactor);
            m_skyCloudMat.SetFloat("_IrradianceMapR_maxAngleRange", m_irradianceMapR_range);

            m_skyCloudMat.SetColor("_SunAdditionColor", m_sunAdditionColor);
            m_skyCloudMat.SetFloat("_SunAdditionIntensity", m_sunAdditionIntensity);
            m_skyCloudMat.SetFloat("_IrradianceMapG_maxAngleRange", m_irradianceMapG_maxAngleRange);
            m_skyCloudMat.SetFloat("_sun_disk_power_999", m_sun_disk_power_999);
            m_skyCloudMat.SetColor("_sun_color", m_sun_color);
            m_skyCloudMat.SetFloat("_sun_color_intensity", m_sun_color_intensity);

            m_skyCloudMat.SetColor("_sun_shine_color", m_sun_shine_color);
            m_skyCloudMat.SetFloat("_SunTransmission", m_sunTransmission);
            m_skyCloudMat.SetFloat("_TransmissionLDotVStartAt", m_transmissionLDotVStartAt);
            m_skyCloudMat.SetColor("_CloudColor_Bright_Center", m_cloudColor_Bright_Center);
            m_skyCloudMat.SetColor("_CloudColor_Bright_Around", m_cloudColor_Bright_Around);
            m_skyCloudMat.SetColor("_CloudColor_Dark_Center", m_cloudColor_Dark_Center);
            m_skyCloudMat.SetColor("_CloudColor_Dark_Around", m_cloudColor_Dark_Around);
            m_skyCloudMat.SetFloat("_CloudTransparency", m_cloudTransparency);
            m_skyCloudMat.SetFloat("_LDotV_damping_factor_cloud", m_lDotV_damping_factor_cloud);
            m_skyCloudMat.SetFloat("_CloudMoreBright", m_cloudMoreBright);
            m_skyCloudMat.SetFloat("_DisturbanceNoiseOffset", m_disturbanceNoiseOffset);
        }

        private void UpdateFog()
        {
            Vector4 ExponentialFogParameters1 = new Vector4(0.0f, m_fogHeightFalloff, 0, m_fogStartDistance);
            // Vector4 ExponentialFogParameters2 = new Vector4(m_fogNoiseIntensity, m_fogNoiseScale, m_fogNoiseSpeed.x, m_fogNoiseSpeed.y);
            Vector4 ExponentialFogParameters3 = new Vector4(m_fogDensity, m_fogHeight, 0, 0);
            Vector4 DirectionalInscatteringColor = new Vector4(m_directionalInscatteringColor.r, m_directionalInscatteringColor.g, m_directionalInscatteringColor.b, m_inscaterringExponent);
            Vector4 ExponentialFogColorParameter = new Vector4(m_fogColor.r, m_fogColor.g, m_fogColor.b, 0);

            Shader.SetGlobalVector("_ExponentialFogParameters1", ExponentialFogParameters1);
            // Shader.SetGlobalVector("_ExponentialFogParameters2", ExponentialFogParameters2);
            Shader.SetGlobalVector("_ExponentialFogParameters3", ExponentialFogParameters3);
            Shader.SetGlobalVector("_DirectionalInscatteringColor", DirectionalInscatteringColor);
            Shader.SetGlobalVector("_ExponentialFogColorParameter", ExponentialFogColorParameter);

        }

        private void UpdateWind()
        {
            Vector3 windDirection = Vector3.Normalize(m_windDirection);
            Shader.SetGlobalVector("_WindDirection", new Vector4(windDirection.x, windDirection.y, windDirection.z, 0));
            Shader.SetGlobalVector("_WindInformation", new Vector4(m_windIntensity, m_turbulence, m_noiseFrequency, m_noiseScale));
        }

        private void UpdateWeather()
        {
            // 临时 第一天下雨，第二天无雨
            float humidity = m_humidity;
            // float humidity = m_humidity * ((currentDay + 1) % 2);

            // 0.001f防止half精度问题
            Shader.SetGlobalVector("_RainInformation", new Vector4(0, 0, Mathf.Max(humidity, 0.001f), Mathf.Max(m_rainNoiseContrast, 0.001f)));

            if(Application.isPlaying){
                for(int i=0; i < m_rainFXs.Length; i++){
                    var emi = m_rainFXs[i].emission;
                    emi.rateOverTimeMultiplier = m_defaultRainFXRateOverTime[i] * humidity;
                }
            }


            Shader.SetGlobalColor("_WaterColor", m_waterColor);
            Shader.SetGlobalTexture("_RainNoiseMap", m_rainNoiseMap);
            Shader.SetGlobalVector("_RainTillingOffset", m_rainNoiseTillingOffset);

            // PlayBGSounds
            if (audioManager != null)
                audioManager.SwitchBGSounds(humidity);
        }

        private void UpdateOthers()
        {
            if(m_flockController != null){
                m_flockController._childAmount = m_birdsNumber;
            }
            
            if(m_kunchongFX != null){
                m_kunchongFX.SetActive(m_mothsVFXOpen);
            }
            
        }

    
        void UpdateAudio(int index)
        {
            if (audioManager)
                audioManager.SwitchDayTimeBGM(index);
        }
    }
}

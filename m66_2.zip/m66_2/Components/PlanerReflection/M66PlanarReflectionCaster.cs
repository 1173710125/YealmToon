using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

[RequireComponent( typeof( Renderer ) )]
[ExecuteAlways]
public class M66PlanarReflectionCaster : MonoBehaviour
{
    public static readonly int _reflectionTex = Shader.PropertyToID( "_ReflectionTex" );
    public M66PlanarReflectionRenderer castFromRenderer;
    private Renderer rend;
    protected MaterialPropertyBlock mBlock;
    private bool[] castReflection = new bool[0];

    private void OnEnable() {
        StartCoroutine(DelayOneFrameCoroutine());
    }

    IEnumerator DelayOneFrameCoroutine()
    {

        // 延后一帧 前一帧可能设置材质球
        yield return null;

        rend = GetComponent<Renderer>();
        rend.sharedMaterial.EnableKeyword("_PLANAR_REFLECTION_CAMERA");

        if ( castReflection.Length != rend.sharedMaterials.Length )
            castReflection = new bool[rend.sharedMaterials.Length];

        RenderPipelineManager.beginCameraRendering -= AssignReflections;
        RenderPipelineManager.beginCameraRendering += AssignReflections;
        RenderPipelineManager.endCameraRendering -= BlackReflection;
        RenderPipelineManager.endCameraRendering += BlackReflection;
    }

    private void OnDisable() {
        RenderPipelineManager.beginCameraRendering -= AssignReflections;
        RenderPipelineManager.endCameraRendering -= BlackReflection;
        if(rend && rend.sharedMaterial){
            rend.sharedMaterial.DisableKeyword("_PLANAR_REFLECTION_CAMERA");
        }
    }

    private void OnDestroy() {
        if(rend && rend.sharedMaterial){
            rend.sharedMaterial.DisableKeyword("_PLANAR_REFLECTION_CAMERA");
        }
    }

    void BlackReflection( ScriptableRenderContext context, Camera cam ) {
        if ( mBlock == null ) {
            mBlock = new MaterialPropertyBlock();
        }

        for ( int i = 0; i < castReflection.Length; i++ ) {
            mBlock.SetTexture( _reflectionTex, Texture2D.blackTexture );
            rend.SetPropertyBlock( mBlock, i );
        }
    }

    void AssignReflections( ScriptableRenderContext context, Camera cam ) {
        if ( mBlock == null ) {
            mBlock = new MaterialPropertyBlock();
        }

        for ( int i = 0; i < castReflection.Length; i++ ) {
            mBlock.SetTexture( _reflectionTex, Texture2D.blackTexture );
            rend.SetPropertyBlock( mBlock, i );
        }

        if ( !castFromRenderer ) {
            return;
        }

        for ( int i = 0; i < castReflection.Length; i++ ) {

            rend.GetPropertyBlock( mBlock, i );

            Texture rTex = castFromRenderer.GetReflection( cam );
            mBlock.SetTexture( _reflectionTex, rTex );

            rend.SetPropertyBlock( mBlock, i );

        }
    }
}

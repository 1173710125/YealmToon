using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.Collections;
using System.Collections.Generic;

// 参考了 PIDI - Planar Reflections™ 5 与 Stylized Water 2 平面反射的做法

// M66 平面反射
// 通过以下方式控制性能：
// 1.Layer控制反射相机渲染物体 + 每个Layer渲染距离
// 2.屏幕分辨率
// 3.在拷贝主相机流程时，关闭不必要的流程

// 目前已关闭的流程：
// SSAO 在SSAO Feature中关闭（通过摄像机名称）
// 阴影shadowmap uData.renderShadows = false;
// 后处理 uData.renderPostProcessing = false

// 后续根据实际情况考虑是否增加的部分
// 1.渲染阴影
// 2.LOD控制（因为当前没有用到LOD模型）
// 3.anti-alising
// 4.blur pass

[System.Serializable]
public class M66PlanarReflectionSettings {

    public LayerMask reflectLayers = 1; //反射物体的layer控制
    // public string camerasPrefix;
    [Range( 0.1f, 1.0f )] public float outputResolutionMultiplier = 0.25f; //反射相机分辨率控制
    [Range( 0f, 1.0f )] public float falloffSpeed = 0f;

    //Layer 距离以及 skybox处理


    //后续根据实际情况可能拓展的部分
    // public bool renderShadows = false;
    // public bool usePostProcessing = false;
    // public LayerMask postFXVolumeMask;

}

[System.Serializable]
public class M66ReflectionData {
    public Camera m_reflectionCam;
    public UniversalAdditionalCameraData m_universalData;
    public RenderTexture m_reflectionTex;
    public Vector2Int m_screenRes;

    public void ForceSetCamera(Camera cam) {
        m_reflectionCam = cam;
        m_universalData = m_reflectionCam.GetUniversalAdditionalCameraData();
    }

    public M66ReflectionData( Camera cam, M66PlanarReflectionSettings settings) {
        m_reflectionCam = cam;
        m_reflectionTex = RenderTexture.GetTemporary( 1, 1 );
        m_screenRes = new Vector2Int(Screen.width, Screen.height);
        m_universalData = m_reflectionCam.GetUniversalAdditionalCameraData();
        RegenerateTextures(settings);
    }

    public void RegenerateTextures(M66PlanarReflectionSettings settings) {
        RenderTexture.ReleaseTemporary(m_reflectionTex);

        int texWidth = Mathf.RoundToInt(settings.outputResolutionMultiplier * Screen.width);
        int texHeight = Mathf.RoundToInt( settings.outputResolutionMultiplier * Screen.height);
        var rd = new RenderTextureDescriptor(texWidth , texHeight);
        rd.useMipMap = false;
        rd.msaaSamples = 1;
        rd.colorFormat = RenderTextureFormat.DefaultHDR;//DefaultHDR
        rd.depthBufferBits = 16;
        rd.autoGenerateMips = false;
        rd.volumeDepth = 1;
        rd.vrUsage = VRTextureUsage.None;
        rd.mipCount = 6;
        rd.dimension = UnityEngine.Rendering.TextureDimension.Tex2D;
        m_reflectionTex = RenderTexture.GetTemporary( rd );
        m_reflectionTex.filterMode = FilterMode.Bilinear;
        
        m_screenRes = new Vector2Int(Screen.width, Screen.height);
        m_reflectionTex.name = $"_ReflectionTex:{texWidth}x{texHeight}";

    }
}

[ExecuteAlways]
public class M66PlanarReflectionRenderer : MonoBehaviour
{
    protected M66ReflectionData _reflectionData;
    [SerializeField] public M66PlanarReflectionSettings _settings = new M66PlanarReflectionSettings();
    GameObject rCam;
    
#if UNITY_EDITOR
    protected M66ReflectionData _sceneReflection;
#endif

    public Texture GetReflection( Camera cam ) {
        //Debug.LogWarning(cam.cameraType + ":get reflection");
#if UNITY_EDITOR
        if ( cam.cameraType == CameraType.SceneView ){
            return _sceneReflection != null && _sceneReflection.m_reflectionTex != null ? (Texture)_sceneReflection.m_reflectionTex : Texture2D.blackTexture;
        }else 
#endif
        if( cam.cameraType == CameraType.Game ) {
            return _reflectionData != null && _reflectionData.m_reflectionTex != null ? (Texture)_reflectionData.m_reflectionTex : Texture2D.blackTexture;
        }else {
            return Texture2D.blackTexture;
        }
    }

#if UNITY_EDITOR
    [UnityEditor.Callbacks.DidReloadScripts]
    private static void OnScriptsReloaded() {
        var cams = Resources.FindObjectsOfTypeAll<Camera>();

        foreach ( Camera cam in cams ) {
            if ( cam.name.Contains( "_ReflectionCamera" ) ) {
                RenderTexture.ReleaseTemporary( cam.targetTexture );
                cam.targetTexture = null;
                DestroyImmediate( cam.gameObject );
            }
        }
    }
#endif

    public void OnEnable() {
#if UNITY_EDITOR
        UnityEditor.Undo.undoRedoPerformed += ApplySettings;
#endif
        RenderPipelineManager.beginCameraRendering += RenderURPReflection;
    }

    public void OnDisable() {
        RenderPipelineManager.beginCameraRendering -= RenderURPReflection;

#if UNITY_EDITOR
        UnityEditor.Undo.undoRedoPerformed -= ApplySettings;
        if(_sceneReflection != null && _sceneReflection.m_reflectionTex != null)
            RenderTexture.ReleaseTemporary( _sceneReflection.m_reflectionTex );
#endif
        if(_reflectionData != null && _reflectionData.m_reflectionTex != null)
            RenderTexture.ReleaseTemporary( _reflectionData.m_reflectionTex );
    }


    public void ApplySettings() {
#if UNITY_EDITOR
        if (_sceneReflection != null && (Screen.width != _sceneReflection.m_screenRes.x || Screen.height !=_sceneReflection.m_screenRes.y)){
            _sceneReflection.RegenerateTextures( _settings );
        }
#endif
        if (_reflectionData != null && (Screen.width != _reflectionData.m_screenRes.x || Screen.height != _reflectionData.m_screenRes.y)){
            _reflectionData.RegenerateTextures( _settings );
        }
    }

    
    public void RenderURPReflection( ScriptableRenderContext context, Camera cam ) {
        // 仅仅包含_settings.camerasPrefix前缀的场景相机 渲染反射效果
        // if ( !string.IsNullOrEmpty( _settings.camerasPrefix ) ) {
        //     if ( cam.cameraType != CameraType.SceneView && !cam.name.Contains( _settings.camerasPrefix ) ) {
        //         return;
        //     }
        // }

        if (cam.cameraType != CameraType.SceneView && cam.cameraType != CameraType.Game) return;
        if (cam.orthographic) return;

        
        // 创建反射相机
        if(rCam == null){
            rCam = new GameObject( "_ReflectionCamera", typeof( Camera ), typeof( Skybox ) );
            rCam.hideFlags = HideFlags.HideAndDontSave;
            rCam.GetComponent<Camera>().enabled = false;
            rCam.GetComponent<Camera>().cameraType = CameraType.Game;
        }


        // 创建反射信息
#if UNITY_EDITOR
        if ( cam.cameraType == CameraType.SceneView ) {
            if ( _sceneReflection == null ) {
                _sceneReflection = new M66ReflectionData( rCam.GetComponent<Camera>(), _settings );
            }
            else {
                _sceneReflection.ForceSetCamera( rCam.GetComponent<Camera>() );
            }
        }
        else
#endif
        if ( cam.cameraType == CameraType.Game && cam.gameObject.hideFlags == HideFlags.None && _reflectionData == null) {
            _reflectionData = new M66ReflectionData( rCam.GetComponent<Camera>(), _settings );
        }
        else if ( cam.gameObject.hideFlags != HideFlags.None ) {
            return;
        }


        // 根据renderer transform创建反射平面
        Plane reflectionPlane = new Plane( transform.up, transform.position );

        // low grazing angle && 相机距离平面很近
        if ( Mathf.Abs( Vector3.Dot( transform.up, cam.transform.forward ) ) < 0.01f && ( reflectionPlane.GetDistanceToPoint( cam.transform.position ) < 0.025f )) {
            return;
        }

        M66ReflectionData currentData;
        //获取并设置反射相机参数
#if UNITY_EDITOR
        if (cam.cameraType == CameraType.SceneView && _sceneReflection != null){
            if ( Screen.width != _sceneReflection.m_screenRes.x || Screen.height != _sceneReflection.m_screenRes.y ) {
                _sceneReflection.RegenerateTextures( _settings );
            }
            currentData = _sceneReflection;
        }else 
#endif
        if(cam.cameraType == CameraType.Game && _reflectionData != null){
            if ( Screen.width != _reflectionData.m_screenRes.x || Screen.height != _reflectionData.m_screenRes.y ) {
                _reflectionData.RegenerateTextures( _settings );
            }
            currentData = _reflectionData;
        }else{
            return;
        }
        
        Camera refCamera = currentData.m_reflectionCam;

        if (refCamera == null) return;

        refCamera.CopyFrom(cam);
        refCamera.allowHDR = true;
        refCamera.allowMSAA = false;
        refCamera.useOcclusionCulling = false;
        refCamera.cullingMask = _settings.reflectLayers;
        refCamera.clearFlags = CameraClearFlags.SolidColor;
        refCamera.backgroundColor = Color.black;
        refCamera.renderingPath = cam.renderingPath;

        Vector3 worldSpaceViewDir = cam.transform.forward;
        Vector3 worldSpaceViewUp = cam.transform.up;
        Vector3 worldSpaceCamPos = cam.transform.position;

        Vector3 planeSpaceViewDir = transform.InverseTransformDirection( worldSpaceViewDir );
        Vector3 planeSpaceViewUp = transform.InverseTransformDirection( worldSpaceViewUp );
        Vector3 planeSpaceCamPos = transform.InverseTransformPoint( worldSpaceCamPos );

        planeSpaceViewDir.y *= -1.0f;
        planeSpaceViewUp.y *= -1.0f;
        planeSpaceCamPos.y *= -1.0f;

        worldSpaceViewDir = transform.TransformDirection( planeSpaceViewDir );
        worldSpaceViewUp = transform.TransformDirection( planeSpaceViewUp );
        worldSpaceCamPos = transform.TransformPoint( planeSpaceCamPos );

        refCamera.transform.position = worldSpaceCamPos;
        refCamera.transform.LookAt( worldSpaceCamPos + worldSpaceViewDir, worldSpaceViewUp );

        refCamera.nearClipPlane = 0.1f;
        refCamera.farClipPlane = 500.0f;
        refCamera.rect = new Rect( 0, 0, 1, 1 );
        refCamera.aspect = cam.aspect;

        //accurate matrix
        refCamera.projectionMatrix = refCamera.CalculateObliqueMatrix( CameraSpacePlane( refCamera, transform.position, transform.up ) );
        refCamera.targetTexture = currentData.m_reflectionTex;

        Shader.SetGlobalVector("_PointOnPlanePositionWS", this.transform.position);
        Shader.SetGlobalVector("_ReflectionPlaneNormalWS", this.transform.up);
        Shader.SetGlobalFloat("_FalloffSpeed", _settings.falloffSpeed);

        // 相机universaldata设置
        var uData = refCamera.GetUniversalAdditionalCameraData();
        uData.renderType = CameraRenderType.Base;
        uData.renderShadows = false;
        uData.renderPostProcessing = false;
        uData.antialiasing = AntialiasingMode.None; //反射 反走样 设置
        //uData.volumeLayerMask = _settings.postFXVolumeMask;
        uData.requiresColorOption = CameraOverrideOption.Off;

        refCamera.enabled = false;

#pragma warning disable 0618
        UniversalRenderPipeline.RenderSingleCamera(context, refCamera); //提交drawcall
#pragma warning restore 0618
    }

    private Vector4 CameraSpacePlane( Camera forCamera, Vector3 planeCenter, Vector3 planeNormal ) {
        Vector3 offsetPos = planeCenter;
        Matrix4x4 mtx = forCamera.worldToCameraMatrix;
        Vector3 cPos = mtx.MultiplyPoint( offsetPos );
        Vector3 cNormal = mtx.MultiplyVector( planeNormal ).normalized * 1;
        return new Vector4( cNormal.x, cNormal.y, cNormal.z, -Vector3.Dot( cPos, cNormal ) );
    }


#if UNITY_EDITOR
    public void OnDrawGizmos() {
        Gizmos.matrix = Matrix4x4.TRS( transform.position, transform.rotation, Vector3.one );
        Gizmos.color = Color.clear;
        Gizmos.DrawCube( Vector3.zero, new Vector3( 1, 0.01f, 1 ) * 10 );
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireCube( Vector3.zero, new Vector3( 1, 0, 1 ) * 10 );
        Gizmos.matrix = Matrix4x4.TRS( Vector3.zero, Quaternion.identity, Vector3.one );
    }

    private void OnValidate() {
        ApplySettings();
    }
#endif


}

using System;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

[Serializable, VolumeComponentMenu("M66Feature/BeforeRenderingSetting")]
public class GlobalParameterSettings : VolumeComponent
{
    public IntParameter width = new MinIntParameter(2400, 720);
    public IntParameter height = new MinIntParameter(1080, 540);
    public TextureParameter brdfLUT = new TextureParameter(null);
    public TextureParameter flowNoiseTexture = new TextureParameter(null);
    public TextureParameter perlinNoiseTexture = new TextureParameter(null);
    public TextureParameter blueNoiseTexture = new TextureParameter(null);
    public TextureParameter otherNoiseTexture1 = new TextureParameter(null);
    public TextureParameter otherNoiseTexture2 = new TextureParameter(null);
    public TextureParameter otherNoiseTexture3 = new TextureParameter(null);
}
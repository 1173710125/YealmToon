using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering.RenderGraphModule;
using NUnit.Framework;

public class BeforeRenderSettingFeature : ScriptableRendererFeature
{
    //opaque前的 global参数设置
    GlobalParameterPass m_GlobalParameterPass = null;
    
    class GlobalParameterPass : ScriptableRenderPass
    {
        private GlobalParameterSettings m_globalSettings;
        private CloudShadowSettings m_cloudShadowSettings;
        private FogSettings m_fogSettings;
        private ProfilingSampler m_profilingSampler = new ProfilingSampler("BeforeRenderingGlobalSetting");

        public GlobalParameterPass(float startTime) : base()
        {

        }

        private class PassData
        {
            internal Camera mainCamera;
            internal GlobalParameterSettings globalSettings;
            internal CloudShadowSettings cloudShadowSettings;
            internal FogSettings fogSettings;
            internal Vector3 playerPosition;
        }

        // This static method is passed as the RenderFunc delegate to the RenderGraph render pass.
        // It is used to execute draw commands.
        static void ExecutePass(PassData data, UnsafeGraphContext context)
        {
            Camera camera =  data.mainCamera;

            //传递额外光数量参数到静态类 以方便UI获取信息
            // if(camera.name == "Camera3D"){
            //     UniversalRenderer renderer = (UniversalRenderer)renderingData.cameraData.renderer;
            //     SceneInfoManager.SetAdditionalLightsCount(renderer.m_ForwardLights.GetAdditionalLightsCount());
            // }

            //创建cmd
            CommandBuffer cmd = CommandBufferHelpers.GetNativeCommandBuffer(context.cmd);

            if(Application.isPlaying){
                cmd.DisableShaderKeyword("_EDITOR_MODE"); 
            }else{
                cmd.EnableShaderKeyword("_EDITOR_MODE");
            }

            cmd.SetGlobalTexture("_BRDFIntegrationMap", data.globalSettings.brdfLUT.value);
            cmd.SetGlobalTexture("_FlowNoiseTexture", data.globalSettings.flowNoiseTexture.value);
            cmd.SetGlobalTexture("_PerlinNoiseTexture", data.globalSettings.perlinNoiseTexture.value);
            cmd.SetGlobalTexture("_BlueNoiseTexture", data.globalSettings.blueNoiseTexture.value);
            cmd.SetGlobalTexture("_OtherNoiseTexture1", data.globalSettings.otherNoiseTexture1.value);
            cmd.SetGlobalTexture("_OtherNoiseTexture2", data.globalSettings.otherNoiseTexture2.value);
            cmd.SetGlobalTexture("_OtherNoiseTexture3", data.globalSettings.otherNoiseTexture3.value);

            cmd.SetGlobalVector("_PlayerPosition", data.playerPosition);

            // 云阴影
            //para1:    xy: cloud move speed        zw:_SmoothStepRange
            //para2:    x: cloud shadow size        yzw:unused
            if(data.cloudShadowSettings.enabled.value == true && camera.cameraType != CameraType.Preview){
                cmd.EnableShaderKeyword("_CLOUD_SHADOW");

                cmd.SetGlobalVector("_CloudShadowParas1", new Vector4(data.cloudShadowSettings.speedUV.value.x, data.cloudShadowSettings.speedUV.value.y, data.cloudShadowSettings.cloudShadowTextureSize.value, 0));
                cmd.SetGlobalVector("_CloudShadowParas2", new Vector4(data.cloudShadowSettings.smoothStepRange.value.x, data.cloudShadowSettings.smoothStepRange.value.y, 0, 0));
                cmd.SetGlobalTexture("_CloudShadowTexture", data.cloudShadowSettings.cloudShadowTexture.value);
            }else{
                cmd.DisableShaderKeyword("_CLOUD_SHADOW");
            }

            // 区分反射相机与正常相机的keyword
            if(camera.name.Contains("ReflectionCamera")){
                cmd.EnableShaderKeyword("_REFLECTION_CAMERA");
                cmd.DisableShaderKeyword("_M66_FOG"); // 反射相机不要拍雾效
            }else{
                cmd.DisableShaderKeyword("_REFLECTION_CAMERA");
                cmd.EnableShaderKeyword("_M66_FOG");
            }
        }

        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            const string passName = "BeforeRenderingGlobalSettings";

            // This adds a raster render pass to the graph, specifying the name and the data type that will be passed to the ExecutePass function.
            using (var builder = renderGraph.AddUnsafePass<PassData>(passName, out var passData, m_profilingSampler))
            {
                    // Access the relevant frame data from the Universal Render Pipeline
                    UniversalRenderingData universalRenderingData = frameData.Get<UniversalRenderingData>();
                    UniversalCameraData cameraData = frameData.Get<UniversalCameraData>();
                    UniversalLightData lightData = frameData.Get<UniversalLightData>();

                    builder.AllowPassCulling(false);
                    builder.AllowGlobalStateModification(true);

                    // 初始化passdata
                    passData.mainCamera = cameraData.camera;
                    passData.globalSettings = m_globalSettings;
                    passData.cloudShadowSettings = m_cloudShadowSettings;
                    passData.fogSettings = m_fogSettings;
                    GameObject player = SceneRoot.Instance.MainCharacter;
                    if(player) passData.playerPosition = player.transform.position;

                    
                    builder.SetRenderFunc((PassData data, UnsafeGraphContext context) => ExecutePass(data, context));
            }
        }

        internal bool Setup(ref RenderingData renderingData)
        {
            m_globalSettings = VolumeManager.instance.stack.GetComponent<GlobalParameterSettings>();
            m_cloudShadowSettings = VolumeManager.instance.stack.GetComponent<CloudShadowSettings>();
            m_fogSettings = VolumeManager.instance.stack.GetComponent<FogSettings>();
        

            // 相机分辨率设置
            if(Application.isPlaying && renderingData.cameraData.camera.name == "Camera3D"){
                // Debug.LogWarning("Set Resolution:" + globalSettings.width.value + "," + globalSettings.height.value);
                renderingData.cameraData.cameraTargetDescriptor.width = m_globalSettings.width.value;
                renderingData.cameraData.cameraTargetDescriptor.height = m_globalSettings.height.value;
            }


            return true;
        }

        [System.Obsolete]
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
            
        }

        [System.Obsolete]
        // Here you can implement the rendering logic.
        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            Camera camera =  renderingData.cameraData.camera;

            //传递额外光数量参数到静态类 以方便UI获取信息
            if(camera.name == "Camera3D"){
                UniversalRenderer renderer = (UniversalRenderer)renderingData.cameraData.renderer;
                // SceneInfoManager.SetAdditionalLightsCount(renderer.m_ForwardLights.GetAdditionalLightsCount());
            }

            //创建cmd
            CommandBuffer cmd = CommandBufferPool.Get("BeforeOpaqueSettings");

            if(Application.isPlaying){
                cmd.DisableShaderKeyword("_EDITOR_MODE"); 
            }else{
                cmd.EnableShaderKeyword("_EDITOR_MODE");
            }

            cmd.SetGlobalTexture("_BRDFIntegrationMap", m_globalSettings.brdfLUT.value);
            cmd.SetGlobalTexture("_FlowNoiseTexture", m_globalSettings.flowNoiseTexture.value);
            cmd.SetGlobalTexture("_PerlinNoiseTexture", m_globalSettings.perlinNoiseTexture.value);
            cmd.SetGlobalTexture("_BlueNoiseTexture", m_globalSettings.blueNoiseTexture.value);
            cmd.SetGlobalTexture("_OtherNoiseTexture1", m_globalSettings.otherNoiseTexture1.value);
            cmd.SetGlobalTexture("_OtherNoiseTexture2", m_globalSettings.otherNoiseTexture2.value);
            cmd.SetGlobalTexture("_OtherNoiseTexture3", m_globalSettings.otherNoiseTexture3.value);


            // 云阴影
            //para1:    xy: cloud move speed        zw:_SmoothStepRange
            //para2:    x: cloud shadow size        yzw:unused
            if(m_cloudShadowSettings.enabled.value == true && camera.cameraType != CameraType.Preview){
                cmd.EnableShaderKeyword("_CLOUD_SHADOW");

                cmd.SetGlobalVector("_CloudShadowParas1", new Vector4(m_cloudShadowSettings.speedUV.value.x, m_cloudShadowSettings.speedUV.value.y, m_cloudShadowSettings.cloudShadowTextureSize.value, 0));
                cmd.SetGlobalVector("_CloudShadowParas2", new Vector4(m_cloudShadowSettings.smoothStepRange.value.x, m_cloudShadowSettings.smoothStepRange.value.y, 0, 0));
                cmd.SetGlobalTexture("_CloudShadowTexture", m_cloudShadowSettings.cloudShadowTexture.value);
            }else{
                cmd.DisableShaderKeyword("_CLOUD_SHADOW");
            }

            // 区分反射相机与正常相机的keyword
            if(camera.name.Contains("ReflectionCamera")){
                cmd.EnableShaderKeyword("_REFLECTION_CAMERA");
                cmd.DisableShaderKeyword("_M66_FOG"); // 反射相机不要拍雾效
            }else{
                cmd.DisableShaderKeyword("_REFLECTION_CAMERA");
                cmd.EnableShaderKeyword("_M66_FOG");
            }

            //execute
            context.ExecuteCommandBuffer(cmd);

            //release
            CommandBufferPool.Release(cmd);
        }

        // Cleanup any allocated resources that were created during the execution of this render pass.
        public override void OnCameraCleanup(CommandBuffer cmd)
        {
        }
    }

    /// <inheritdoc/>
    public override void Create()
    {
        #if UNITY_EDITOR
            float startTime = Application.isPlaying ? Time.time : Time.realtimeSinceStartup;
        #else
            float startTime = Time.time;
        #endif
        m_GlobalParameterPass = new GlobalParameterPass(startTime);

        // Configures where the render pass should be injected.
        m_GlobalParameterPass.renderPassEvent = RenderPassEvent.BeforeRendering;
    }

    // Here you can inject one or multiple render passes in the renderer.
    // This method is called when setting up the renderer once per-camera.
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if(renderingData.cameraData.camera.name == "Camera3D" 
        || renderingData.cameraData.camera.name.Contains("ReflectionCamera")
        || renderingData.cameraData.camera.name == "SceneCamera" ){

            if(m_GlobalParameterPass.Setup(ref renderingData)){
                renderer.EnqueuePass(m_GlobalParameterPass);
            }
            
        }
            
    }
}



using System;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

[Serializable, VolumeComponentMenu("Before-Opaque/FogSetting")]
public class FogSettings : VolumeComponent, IPostProcessComponent
{
    // Parameters
    [InspectorName("开启高度深度雾")]
    [SerializeField] public BoolParameter enabled = new BoolParameter(false);
    [InspectorName("FogHeightFalloff")]
    [SerializeField] public FloatParameter FogHeightFalloff = new FloatParameter(0.0f);
    [InspectorName("FogStartDistance")]
    [SerializeField] public FloatParameter FogStartDistance = new FloatParameter(0.0f);
    [InspectorName("FogDensity")]
    [SerializeField] public FloatParameter FogDensity = new FloatParameter(0.0f);
    [InspectorName("FogHeight")]
    [SerializeField] public FloatParameter FogHeight = new FloatParameter(0.0f);
    [InspectorName("FogCutoffDistance")]
    [SerializeField] public FloatParameter FogCutoffDistance = new FloatParameter(0.0f);
    [InspectorName("FogMinTransparency")]
    [SerializeField] public FloatParameter FogMinTransparency = new FloatParameter(0.0f);
    [InspectorName("FogColor")]
    [SerializeField] public ColorParameter FogColor = new ColorParameter(new Color(0.3f, 0.3f, 0.3f, 1.0f));
    [InspectorName("DirectionalInscatteringColor")]
    [SerializeField] public ColorParameter DirectionalInscatteringColor = new ColorParameter(new Color(0.3f, 0.3f, 0.3f, 1.0f));
    [InspectorName("直接光散射程度")]
    [SerializeField] public FloatParameter InscaterringExponent = new FloatParameter(0.0f);
    [InspectorName("InscatteringLightDirection")]
    [SerializeField] public Vector3Parameter InscatteringLightDirection = new Vector3Parameter(Vector3.zero);
    [InspectorName("InscaterringStartDistance")]
    [SerializeField] public FloatParameter InscaterringStartDistance = new FloatParameter(0.0f);

    [InspectorName("FogHeightFalloff变化幅度")]
    [SerializeField] public FloatParameter FogHeightFalloffExtent = new FloatParameter(0.0f);
    [InspectorName("FogHeightFalloff变化速度")]
    [SerializeField] public FloatParameter FogHeightFalloffSpeed = new FloatParameter(0.0f);
    [InspectorName("FogDensity变化幅度")]
    [SerializeField] public FloatParameter FogDensityExtent = new FloatParameter(0.0f);
    [InspectorName("FogDensity变化速度")]
    [SerializeField] public FloatParameter FogDensitySpeed = new FloatParameter(0.0f);
    [InspectorName("FogHeight变化幅度")]
    [SerializeField] public FloatParameter FogHeightExtent = new FloatParameter(0.0f);
    [InspectorName("FogHeight变化速度")]
    [SerializeField] public FloatParameter FogHeightSpeed = new FloatParameter(0.0f);

    
    public bool IsActive()
    {
        return enabled.value;
    }

    public bool IsTileCompatible()
    {
        return false;
    }
}
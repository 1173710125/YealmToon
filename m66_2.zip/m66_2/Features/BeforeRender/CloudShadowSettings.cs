using System;
using UnityEngine;
using UnityEngine.Rendering;

[Serializable, VolumeComponentMenu("Before-Opaque/CloudShadowSetting")]
public class CloudShadowSettings : VolumeComponent
{
    [InspectorName("enabled")]
    public BoolParameter enabled = new BoolParameter(false);
    [InspectorName("云阴影纹理")]
    public TextureParameter cloudShadowTexture = new TextureParameter(null);
    [InspectorName("云阴影纹理缩放")]
    public FloatParameter cloudShadowTextureSize = new FloatParameter(1.0f);
    [InspectorName("云阴影移动速度")]
    public Vector2Parameter speedUV = new Vector2Parameter(Vector2.one);
    [InspectorName("云阴影边缘过渡")]
    public FloatRangeParameter smoothStepRange = new FloatRangeParameter(new Vector2(0.45f, 0.55f), 0, 1);

    

}
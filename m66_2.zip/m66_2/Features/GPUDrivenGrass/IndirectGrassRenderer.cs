using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor;
using System.IO;

[ExecuteAlways]
public class IndirectGrassRenderer : MonoBehaviour
{
    [Serializable]
    public struct GrassSetting{
        public Material grassMaterial;
        public Mesh grassMesh;
        [Range(-1, 1)]public float grassRandomNormal;
        public Texture2D groundDiffuseTexture;
        public Texture2D groundNormalTexture;
        public Color groundDiffuseBaseColor;
        [Range(0, 50)]public float groundDiffuseRange;

        public Texture2D grassTopColorTexture;
        public Color grassTopBaseColor;
        public Vector4 topColorTextureTilling;
        public GameObject groundReference;
        
    }

    [Serializable]
    public struct InteractionSetting{
        public float interactionCenterHeight;
        public float interactionRadius;
        public float interactionStrength;
    }


    public GrassSetting m_grassSetting;
    public InteractionSetting m_interactionSetting;

    [Header("Settings")]
    public float drawDistance = 100;//this setting will affect performance a lot!
    public ComputeShader cullingComputeShader;
    [HideInInspector]   
    public static IndirectGrassRenderer instance;// global ref to this script
    private int cellCountX = -1;
    private int cellCountZ = -1;
    private int dispatchCount = -1;

    //smaller the number, CPU needs more time, but GPU is faster
    private float cellSizeX = 20; //unity unit (m)
    private float cellSizeZ = 20; //unity unit (m)

    private int m_instanceCountCache = -1;

    [HideInInspector]   
    public ComputeBuffer m_allInstancesPosWSBuffer;
    [HideInInspector]   
    public ComputeBuffer m_visibleInstancesOnlyPosWSIDBuffer;
    [HideInInspector]   
    public ComputeBuffer m_argsBuffer;

    [HideInInspector]   
    public List<Vector4>[] m_cellPosWSsList; //for binning: binning will put each posWS into correct cell
    private float minX, minZ, maxX, maxZ;
    [HideInInspector]   
    public List<int> m_visibleCellIDList = new List<int>();
    private Plane[] cameraFrustumPlanes = new Plane[6];

    [NonSerialized]
    private List<Vector4> m_allGrassPos = new List<Vector4>();//user should update this list using C#
    private int m_instanceCount = -1;
    private int m_cacheCount = 0;
    private uint[] args = new uint[5] { 0, 0, 0, 0, 0 };

    bool shouldBatchDispatch = true;
    public GameObject m_player;

    private void Start()
    {
    }

    private void OnEnable()
    {
        instance = this; 
        UpdatePosIfNeeded();
        UpdateGrassInformation();

        if(!Application.isPlaying) return;

        // disable所有子项
        int childCount = transform.childCount;

        for (int i = 0; i < childCount; i++)
        {
            // 获取每一个子对象
            Transform child = transform.GetChild(i);

            // 设置子对象为不活动状态
            child.gameObject.SetActive(false);
        }
    }

    private void OnValidate()
    {
        UpdateGrassInformation();
    }

    private void UpdateGrassInformation()
    {
        m_grassSetting.grassMaterial.SetFloat("_GrassHeightMin", m_grassSetting.grassMesh.bounds.min.y);
        m_grassSetting.grassMaterial.SetFloat("_GrassHeightMax", m_grassSetting.grassMesh.bounds.max.y);
        m_grassSetting.grassMaterial.SetFloat("_GrassRandomNormal", m_grassSetting.grassRandomNormal);

        // 更新草地的地表diffuse贴图
        Renderer groundRenderer = m_grassSetting.groundReference.GetComponent<Renderer>();
        Bounds bounds = groundRenderer.bounds;
        float largerExtent = Mathf.Max(bounds.extents.x, bounds.extents.z);
        m_grassSetting.grassMaterial.SetVector("_GroundRange", new Vector4(bounds.center.x - largerExtent, bounds.center.z - largerExtent, bounds.center.x + largerExtent, bounds.center.z + largerExtent));// 地表大小范围，借由此获取草采样地表diffuse贴图的uv
        m_grassSetting.grassMaterial.SetTexture("_GroundDiffuseTexture", m_grassSetting.groundDiffuseTexture);
        m_grassSetting.grassMaterial.SetTexture("_GroundNormalTexture", m_grassSetting.groundNormalTexture);
        m_grassSetting.grassMaterial.SetTexture("_TopColorTexture", m_grassSetting.grassTopColorTexture);
        m_grassSetting.grassMaterial.SetVector("_TopColorTextureTilling", m_grassSetting.topColorTextureTilling);
        m_grassSetting.grassMaterial.SetVector("_GrassTopBaseColor", m_grassSetting.grassTopBaseColor);
        m_grassSetting.grassMaterial.SetColor("_GroundDiffuseBaseColor", m_grassSetting.groundDiffuseBaseColor);
        m_grassSetting.grassMaterial.SetFloat("_GroundDiffuseRange", m_grassSetting.groundDiffuseRange);

        Shader.SetGlobalFloat("_InteractionRadius", m_interactionSetting.interactionRadius);
        Shader.SetGlobalFloat("_InteractionStrength", m_interactionSetting.interactionStrength);

    }



#if UNITY_EDITOR

/// <summary>
/// editor下烘焙地表贴图（包含albedo 与 normal）
/// 在地形绘制后需要调用此函数烘焙
/// </summary>
    [ContextMenu("BakeGroundTexture")]
    private void BakeGroundTexture()
    {
        // 创建相机 （俯视 正交 根据地面bounds设置相机size）
        GameObject cameraObject = new GameObject("GroundBakeCamera");

        Camera groundBakeCamera = cameraObject.AddComponent<Camera>();
        Renderer groundRenderer = m_grassSetting.groundReference.GetComponent<Renderer>();
        Bounds bounds = groundRenderer.bounds;

        Vector3 cameraPosition = bounds.center + new Vector3(0, bounds.extents.y + 10.0f, 0); 
        groundBakeCamera.transform.position = cameraPosition;
        groundBakeCamera.transform.LookAt(bounds.center);

        groundBakeCamera.orthographic = true;
        float largerExtent = Mathf.Max(bounds.extents.x, bounds.extents.z);
        groundBakeCamera.orthographicSize = largerExtent;

///////////////////////////////// albedo texture /////////////////////////////////
        RenderTexture renderTextureDiffuse = new RenderTexture(1024, 1024, 24);
        groundBakeCamera.targetTexture = renderTextureDiffuse;

        int groundLayer = LayerMask.NameToLayer("Ground");
        if (groundLayer == -1)
        {
            Debug.LogError("Layer 'Ground' not found, please ensure it is created in the Project Settings.");
            return;
        }
        groundBakeCamera.cullingMask = 1 << groundLayer;

        // 设置场景物体仅仅输出diffuse,然后拍照 
        Shader.DisableKeyword("_DISABLE_DEBUG");
        Shader.DisableKeyword("_DEBUG_ALBEDO");
        Shader.DisableKeyword("_DEBUG_NORMALTS");
        Shader.DisableKeyword("_DEBUG_NORMALWS");
        Shader.DisableKeyword("_DEBUG_MAINLIGHT_RESULT");
        Shader.DisableKeyword("_DEBUG_ADDLIGHT_RESULT");
        Shader.DisableKeyword("_DEBUG_BAKE_LIGHT_RESULT");
        Shader.DisableKeyword("_DEBUG_SKYBOX_LIGHT_RESULT");
        Shader.DisableKeyword("_DEBUG_PROBE_RESULT");
        Shader.DisableKeyword("_DEBUG_REFLECTION_RESULT");
        Shader.DisableKeyword("_DEBUG_EMISSION");
        Shader.DisableKeyword("_DEBUG_SSAO");
        Shader.DisableKeyword("_DEBUG_DEPTH");
        Shader.DisableKeyword("_DEBUG_ROUGHNESS");
        Shader.DisableKeyword("_DEBUG_METALLIC");
        Shader.DisableKeyword("_DEBUG_CUSTOM_DATA");
        Shader.EnableKeyword("_DEBUG_ALBEDO");
        groundBakeCamera.Render();

        // 拍完照后 保存贴图
        Texture2D diffuseTexture2D = new Texture2D(1024, 1024, TextureFormat.RGB24, false);
        RenderTexture.active = renderTextureDiffuse;
        diffuseTexture2D.ReadPixels(new Rect(0, 0, 1024, 1024), 0, 0);
        diffuseTexture2D.Apply();

        byte[] diffuseBytes = diffuseTexture2D.EncodeToPNG();
         // 获取当前活动场景
        Scene currentScene = SceneManager.GetActiveScene();

        // 获取场景名称
        string sceneName = currentScene.name;
        string diffuseFilePath = Path.Combine(Application.dataPath, @"Unpack\_GraphicEngineer",sceneName + "GroundDiffuse.png");
        File.WriteAllBytes(diffuseFilePath, diffuseBytes);
        Debug.Log("Saved Render Texture to " + diffuseFilePath);


///////////////////////////////// normal texture /////////////////////////////////

        RenderTexture renderTextureNormal = new RenderTexture(1024, 1024, 24);
        groundBakeCamera.targetTexture = renderTextureNormal;

        // 设置场景物体仅仅输出normalWS,然后拍照 
        Shader.EnableKeyword("_DEBUG_NORMALWS");
        Shader.DisableKeyword("_DEBUG_ALBEDO");
        groundBakeCamera.Render();

        // 拍完照后 保存贴图
        Texture2D normalTexture2D = new Texture2D(1024, 1024, TextureFormat.RGB24, false);
        RenderTexture.active = renderTextureNormal;
        normalTexture2D.ReadPixels(new Rect(0, 0, 1024, 1024), 0, 0);
        normalTexture2D.Apply();

        byte[] normalBytes = normalTexture2D.EncodeToPNG();

        // 获取场景名称
        string normalFilePath = Path.Combine(Application.dataPath, @"Unpack\_GraphicEngineer", sceneName + "GroundNormal.png");
        File.WriteAllBytes(normalFilePath, normalBytes);
        Debug.Log("Saved Render Texture to " + normalFilePath);

        // 回退diffuse的设置
        Shader.DisableKeyword("_DISABLE_DEBUG");
        Shader.DisableKeyword("_DEBUG_ALBEDO");
        Shader.DisableKeyword("_DEBUG_NORMALTS");
        Shader.DisableKeyword("_DEBUG_NORMALWS");
        Shader.DisableKeyword("_DEBUG_MAINLIGHT_RESULT");
        Shader.DisableKeyword("_DEBUG_ADDLIGHT_RESULT");
        Shader.DisableKeyword("_DEBUG_BAKE_LIGHT_RESULT");
        Shader.DisableKeyword("_DEBUG_SKYBOX_LIGHT_RESULT");
        Shader.DisableKeyword("_DEBUG_PROBE_RESULT");
        Shader.DisableKeyword("_DEBUG_REFLECTION_RESULT");
        Shader.DisableKeyword("_DEBUG_EMISSION");
        Shader.DisableKeyword("_DEBUG_SSAO");
        Shader.DisableKeyword("_DEBUG_DEPTH");
        Shader.DisableKeyword("_DEBUG_ROUGHNESS");
        Shader.DisableKeyword("_DEBUG_METALLIC");
        Shader.DisableKeyword("_DEBUG_CUSTOM_DATA");
        Shader.EnableKeyword("_DISABLE_DEBUG");

        // 释放资源
        RenderTexture.active = null;
        DestroyImmediate(diffuseTexture2D);
        DestroyImmediate(normalTexture2D);
        DestroyImmediate(cameraObject);
        renderTextureDiffuse.Release();
        renderTextureNormal.Release();

        AssetDatabase.Refresh();
    }

/// <summary>
/// 替换网格
/// 在草网格更改时需要调用此函数
/// </summary>
    [ContextMenu("ReplacePrefabMesh")]
    private void ReplacePrefabMesh()
    {
        // disable所有子项
        int childCount = transform.childCount;

        for (int i = 0; i < childCount; i++)
        {
            // 获取每一个子对象
            Transform child = transform.GetChild(i);

            // 设置子对象为不活动状态
            MeshFilter meshFilter = child.GetComponent<MeshFilter>();
            if(meshFilter != null){
                meshFilter.mesh = m_grassSetting.grassMesh;
            }
        }
    }
#endif

    private void Update()
    {
        if(!Application.isPlaying){
            UpdateGrassInformation();
        }
        UpdatePosIfNeeded();

        if (m_player == null)
            m_player = SceneRoot.Instance.MainCharacter;

        if(m_player)
        {
            Vector3 position = m_player.transform.position;
            Shader.SetGlobalVector("_PlayerPosition", new Vector4(position.x, position.y + m_interactionSetting.interactionCenterHeight, position.z, 0));
        }
        
    } 

    void LateUpdate()
    {
        if(!Application.isPlaying) return;

        // recreate all buffers if needed
        UpdateAllInstanceTransformBufferIfNeeded();

        //=====================================================================================================
        // rough quick big cell frustum culling in CPU first
        //=====================================================================================================
        m_visibleCellIDList.Clear();//fill in this cell ID list using CPU frustum culling first
        Camera cam = Camera.main;

        //Do frustum culling using per cell bound
        //https://docs.unity3d.com/ScriptReference/GeometryUtility.CalculateFrustumPlanes.html
        //https://docs.unity3d.com/ScriptReference/GeometryUtility.TestPlanesAABB.html
        float cameraOriginalFarPlane = cam.farClipPlane;
        cam.farClipPlane = drawDistance;//allow drawDistance control    
        GeometryUtility.CalculateFrustumPlanes(cam, cameraFrustumPlanes);//Ordering: [0] = Left, [1] = Right, [2] = Down, [3] = Up, [4] = Near, [5] = Far
        cam.farClipPlane = cameraOriginalFarPlane;//revert far plane edit

        //slow loop
        //TODO: (A)replace this forloop by a quadtree test?
        //TODO: (B)convert this forloop to job+burst? (UnityException: TestPlanesAABB can only be called from the main thread.)
        UnityEngine.Profiling.Profiler.BeginSample("CPU cell frustum culling (heavy)");
        
        for (int i = 0; i < m_cellPosWSsList.Length; i++)
        {
            //create cell bound
            Vector3 centerPosWS = new Vector3 (i % cellCountX + 0.5f, 0, i / cellCountX + 0.5f);
            centerPosWS.x = Mathf.Lerp(minX, maxX, centerPosWS.x / cellCountX);
            centerPosWS.z = Mathf.Lerp(minZ, maxZ, centerPosWS.z / cellCountZ);
            Vector3 sizeWS = new Vector3(Mathf.Abs(maxX - minX) / cellCountX, 100.0f, Mathf.Abs(maxX - minX) / cellCountX);
            Bounds cellBound = new Bounds(centerPosWS, sizeWS);

            if (GeometryUtility.TestPlanesAABB(cameraFrustumPlanes, cellBound))
            {
                m_visibleCellIDList.Add(i);
            }
        }
        UnityEngine.Profiling.Profiler.EndSample();

        //=====================================================================================================
        // loop though only visible cells, each visible cell dispatch GPU culling job once
        // at the end compute shader will fill all visible instance into m_visibleInstancesOnlyPosWSIDBuffer
        //=====================================================================================================
        Matrix4x4 v = cam.worldToCameraMatrix;
        Matrix4x4 p = cam.projectionMatrix;
        Matrix4x4 vp = p * v;

        m_visibleInstancesOnlyPosWSIDBuffer.SetCounterValue(0);

        //set once only
        cullingComputeShader.SetMatrix("_VPMatrix", vp);
        cullingComputeShader.SetFloat("_MaxDrawDistance", drawDistance);

        args[1] = 0;
        m_argsBuffer.SetData(args);

        // dispatch per visible cell
    }

    private void OnDisable()
    {
        //release all compute buffers
        if (m_allInstancesPosWSBuffer != null)
            m_allInstancesPosWSBuffer.Release();
        m_allInstancesPosWSBuffer = null;

        if (m_visibleInstancesOnlyPosWSIDBuffer != null)
            m_visibleInstancesOnlyPosWSIDBuffer.Release();
        m_visibleInstancesOnlyPosWSIDBuffer = null;

        if (m_argsBuffer != null)
            m_argsBuffer.Release();
        m_argsBuffer = null;

        instance = null;
    }

    void UpdateAllInstanceTransformBufferIfNeeded()
    {
        if(!Application.isPlaying) return;

        //early exit if no need to update buffer
        if (m_instanceCountCache == m_allGrassPos.Count &&
            m_argsBuffer != null &&
            m_allInstancesPosWSBuffer != null &&
            m_visibleInstancesOnlyPosWSIDBuffer != null)
            {
                return;
            }

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        Debug.Log("UpdateAllInstanceTransformBuffer (Slow)");

        ///////////////////////////
        // m_allInstancesPosWSBuffer buffer
        ///////////////////////////
        if (m_allInstancesPosWSBuffer != null)
            m_allInstancesPosWSBuffer.Release();
        m_allInstancesPosWSBuffer = new ComputeBuffer(m_allGrassPos.Count, sizeof(float)*4); //float3 posWS only, per grass

        if (m_visibleInstancesOnlyPosWSIDBuffer != null)
            m_visibleInstancesOnlyPosWSIDBuffer.Release();
        m_visibleInstancesOnlyPosWSIDBuffer = new ComputeBuffer(m_allGrassPos.Count, sizeof(uint), ComputeBufferType.Append); //uint only, per visible grass

        //find all instances's posWS XZ bound min max
        minX = float.MaxValue;
        minZ = float.MaxValue;
        maxX = float.MinValue;
        maxZ = float.MinValue;
        for (int i = 0; i < m_allGrassPos.Count; i++)
        {
            Vector4 target = m_allGrassPos[i];
            minX = Mathf.Min(target.x, minX);
            minZ = Mathf.Min(target.z, minZ);
            maxX = Mathf.Max(target.x, maxX);
            maxZ = Mathf.Max(target.z, maxZ);
        }

        //decide cellCountX,Z here using min max
        //each cell is cellSizeX x cellSizeZ
        cellCountX = Mathf.CeilToInt((maxX - minX) / cellSizeX); 
        cellCountZ = Mathf.CeilToInt((maxZ - minZ) / cellSizeZ);

        //init per cell posWS list memory
        m_cellPosWSsList = new List<Vector4>[cellCountX * cellCountZ]; //flatten 2D array
        for (int i = 0; i < m_cellPosWSsList.Length; i++)
        {
            m_cellPosWSsList[i] = new List<Vector4>();
        }

        //binning, put each posWS into the correct cell
        for (int i = 0; i < m_allGrassPos.Count; i++)
        {
            Vector4 pos = m_allGrassPos[i];

            //find cellID
            int xID = Mathf.Min(cellCountX-1,Mathf.FloorToInt(Mathf.InverseLerp(minX, maxX, pos.x) * cellCountX)); //use min to force within 0~[cellCountX-1]  
            int zID = Mathf.Min(cellCountZ-1,Mathf.FloorToInt(Mathf.InverseLerp(minZ, maxZ, pos.z) * cellCountZ)); //use min to force within 0~[cellCountZ-1]

            m_cellPosWSsList[xID + zID * cellCountX].Add(pos);
        }

        //combine to a flatten array for compute buffer
        int offset = 0;
        Vector4[] allGrassPosWSSortedByCell = new Vector4[m_allGrassPos.Count];
        for (int i = 0; i < m_cellPosWSsList.Length; i++)
        {
            for (int j = 0; j < m_cellPosWSsList[i].Count; j++)
            {
                allGrassPosWSSortedByCell[offset] = m_cellPosWSsList[i][j];
                offset++;
            }
        }

        m_allInstancesPosWSBuffer.SetData(allGrassPosWSSortedByCell);
        m_grassSetting.grassMaterial.SetBuffer("_AllInstancesTransformBuffer", m_allInstancesPosWSBuffer);
        m_grassSetting.grassMaterial.SetBuffer("_VisibleInstanceOnlyTransformIDBuffer", m_visibleInstancesOnlyPosWSIDBuffer);

        ///////////////////////////
        // Indirect args buffer
        ///////////////////////////
        if (m_argsBuffer != null)
            m_argsBuffer.Release();
        m_argsBuffer = new ComputeBuffer(1, args.Length * sizeof(uint), ComputeBufferType.IndirectArguments);

        args[0] = (uint)GetGrassMeshCache().GetIndexCount(0); // Gets the index count
        args[1] = 0;
        args[2] = (uint)GetGrassMeshCache().GetIndexStart(0); // Gets the starting index location within the Mesh's index buffer
        args[3] = (uint)GetGrassMeshCache().GetBaseVertex(0); // Gets the base vertex index of the given sub-mesh.
        args[4] = 0;

        m_argsBuffer.SetData(args);

        ///////////////////////////
        // Update Cache
        ///////////////////////////
        //update cache to prevent future no-op buffer update, which waste performance
        m_instanceCountCache = m_allGrassPos.Count;


        //set buffer
        cullingComputeShader.SetBuffer(0, "_AllInstancesPosWSBuffer", m_allInstancesPosWSBuffer);
        cullingComputeShader.SetBuffer(0, "_VisibleInstancesOnlyPosWSIDBuffer", m_visibleInstancesOnlyPosWSIDBuffer);
        cullingComputeShader.SetBuffer(0, "_BufferWithArgs", m_argsBuffer);
    }

    private void UpdatePosIfNeeded()
    {
        if (m_instanceCount == m_cacheCount)
            return;

        m_instanceCount = transform.childCount;
        List<Vector4> positions = new List<Vector4>(m_instanceCount);

        foreach (Transform child in this.transform)
        {
            Vector3 pos = child.position;
            positions.Add(new Vector4(pos.x, pos.y, pos.z, child.lossyScale.y));
        }

        //send all posWS to renderer
        m_allGrassPos = positions;
        m_cacheCount = positions.Count;
    }

    Mesh GetGrassMeshCache()
    {
        return m_grassSetting.grassMesh;
    }
}

using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering.RenderGraphModule;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Experimental.Rendering;

public class IndirectGrassFeature : ScriptableRendererFeature
{
    HiZBufferGeneratePass m_HiZBufferGeneratePass = null;
    IndirectGrassCullingPass m_IndirectGrassCullingPass = null;
    IndirectGrassDrawingPass m_IndirectGrassDrawingPass = null;

    // 此pass最优先，生成HiZ所需的depth buffer以及对应mipmap
    class HiZBufferGeneratePass : ScriptableRenderPass
    {
        private static readonly int s_CameraDepthTextureID = Shader.PropertyToID("_CameraDepthTexture");
        private static readonly int k_mipCount = 7;
        private int ID_depthTexture;
        private int ID_invSize;
        private Material m_copyDepthMaterial;
        private Material m_hzbmat;
        private TextureHandle[] m_HiZDepthBuffer = new TextureHandle[k_mipCount]; // 512 ~ 8
        private ProfilingSampler m_ProfilingSampler = new ProfilingSampler("HiZBufferGeneratePass");

        public HiZBufferGeneratePass()
        {
            if (GraphicsSettings.TryGetRenderPipelineSettings<UniversalRendererResources>(
                    out var universalRendererShaders))
            {
                Shader copyDepthPS = universalRendererShaders.copyDepthPS;
                m_copyDepthMaterial = copyDepthPS != null ? CoreUtils.CreateEngineMaterial(copyDepthPS) : null;
            }
            Shader HiZShader = Shader.Find("M66-2/Rendering/HZBBuild");
            m_hzbmat = HiZShader != null ? new Material(HiZShader) : null;
        }

        private class PassData
        {
            internal Material HiZBufferBuildMaterial;
            internal Material copyDepthMaterial;
            internal TextureHandle[] HiZDepthBuffer;
            internal TextureHandle resourceDepthTexture;
        }

        static void ExecutePass(PassData data, UnsafeGraphContext context)
        {
            var cmd = CommandBufferHelpers.GetNativeCommandBuffer(context.cmd);

            var loadAction = RenderBufferLoadAction.DontCare;   // Blit - always write all pixels
            var storeAction = RenderBufferStoreAction.Store;    // Blit - always read by then next Blit

            //Blit
            Blitter.BlitCameraTexture(cmd, data.resourceDepthTexture, data.HiZDepthBuffer[0], 0, true);

            //generate mipmap
            for(int i = 1; i < k_mipCount; i++)
            {
                TextureHandle lastMip = data.HiZDepthBuffer[i-1];
                TextureHandle currentMip = data.HiZDepthBuffer[i];
                Blitter.BlitCameraTexture(cmd, lastMip, currentMip, loadAction, storeAction, data.HiZBufferBuildMaterial, 0);
            }
            
        }

        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            const string passName = "HiZBufferGeneratePass";

            // Access the relevant frame data from the Universal Render Pipeline
            UniversalRenderingData universalRenderingData = frameData.Get<UniversalRenderingData>();
            UniversalCameraData cameraData = frameData.Get<UniversalCameraData>();
            UniversalLightData lightData = frameData.Get<UniversalLightData>();
            UniversalResourceData resourceData = frameData.Get<UniversalResourceData>();

            RenderTextureDescriptor descriptor = cameraData.cameraTargetDescriptor;

            // 创建RT
            descriptor.width = 512;
            descriptor.height = 256;

            descriptor.depthStencilFormat = GraphicsFormat.None;
            descriptor.msaaSamples = 1;
            descriptor.graphicsFormat = GraphicsFormat.R16_SFloat;
            descriptor.autoGenerateMips = false;
            descriptor.useMipMap = false;

            for(int i = 0; i < k_mipCount; i++)
            {
                m_HiZDepthBuffer[i] = UniversalRenderer.CreateRenderGraphTexture(renderGraph, descriptor, "HiZDepthBufferMip" + i, false, FilterMode.Bilinear);
                descriptor.width = Mathf.Max(1, descriptor.width >> 1);
                descriptor.height = Mathf.Max(1, descriptor.height >> 1);
            }

            using (var builder = renderGraph.AddUnsafePass<PassData>(passName, out var passData, m_ProfilingSampler))
            {
                //initialize passData
                passData.HiZBufferBuildMaterial = m_hzbmat;
                passData.copyDepthMaterial = m_copyDepthMaterial;
                passData.HiZDepthBuffer = m_HiZDepthBuffer;
                passData.resourceDepthTexture = resourceData.cameraDepthTexture;

                builder.AllowPassCulling(false);
                // useTexture
                // builder.UseTexture(resourceData.cameraDepthTexture, AccessFlags.Read);
                for(int i = 0; i < k_mipCount; i++)
                {
                    builder.UseTexture(m_HiZDepthBuffer[i], AccessFlags.ReadWrite);
                }
                
                builder.SetRenderFunc((PassData data, UnsafeGraphContext context) => ExecutePass(data, context));
            }
        }


        [System.Obsolete]
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {

        }

        [System.Obsolete]
        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {

        }

        public void Dispose()
        {
            CoreUtils.Destroy(m_hzbmat);
            CoreUtils.Destroy(m_copyDepthMaterial);
        }
    }

    // 草的剔除pass
    class IndirectGrassCullingPass : ScriptableRenderPass
    {
        private IndirectGrassRenderer m_IndirectGrassRenderer;
        private ProfilingSampler m_ProfilingSampler = new ProfilingSampler("IndirectGrassCullingPass");

        internal bool Setup(ref RenderingData renderingData, IndirectGrassRenderer grassRenderer)
        {
            m_IndirectGrassRenderer = grassRenderer;

            return true;
        }

        private class PassData
        {

        }

        static void ExecutePass(IndirectGrassRenderer indirectGrassRenderer, UnsafeGraphContext context)
        {
            CommandBuffer cmd = CommandBufferHelpers.GetNativeCommandBuffer(context.cmd);

            // dispatch per visible cell
            // 所有的 dispatch部分交给rendererFeature，以免出现在unknown scope中不方便debug
            // 而且可以精准控制dispatch时机
            // todo:job system
            int dispatchCount = 0;

            for (int i = 0; i < indirectGrassRenderer.m_visibleCellIDList.Count; i++)
            {
                int targetCellFlattenID = indirectGrassRenderer.m_visibleCellIDList[i];
                int memoryOffset = 0;
                for (int j = 0; j < targetCellFlattenID; j++)
                {
                    memoryOffset += indirectGrassRenderer.m_cellPosWSsList[j].Count;
                }
                cmd.SetComputeIntParam(indirectGrassRenderer.cullingComputeShader, "_StartOffset", memoryOffset);//culling read data started at offseted pos, will start from cell's total offset in memory
                int jobLength = indirectGrassRenderer.m_cellPosWSsList[targetCellFlattenID].Count;

                //============================================================================================
                //batch n dispatchs into 1 dispatch, if memory is continuous in m_allInstancesPosWSBuffer
                while ((i < indirectGrassRenderer.m_visibleCellIDList.Count - 1) && //test this first to avoid out of bound access to visibleCellIDList
                        (indirectGrassRenderer.m_visibleCellIDList[i + 1] == indirectGrassRenderer.m_visibleCellIDList[i] + 1))
                {
                    //if memory is continuous, append them together into the same dispatch call
                    jobLength += indirectGrassRenderer.m_cellPosWSsList[indirectGrassRenderer.m_visibleCellIDList[i + 1]].Count;
                    i++;
                }

                //============================================================================================

                if(jobLength > 0){
                    cmd.DispatchCompute(indirectGrassRenderer.cullingComputeShader, 0, Mathf.CeilToInt(jobLength / 64f), 1, 1);
                    dispatchCount++;
                }
            }
        }

        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            const string passName = "IndirectGrassCullingPass";

            using (var builder = renderGraph.AddUnsafePass<PassData>(passName, out var passData, m_ProfilingSampler))
            {
                builder.AllowPassCulling(false);// 必须的，否则pass被自动剔除了
                builder.SetRenderFunc((PassData data, UnsafeGraphContext context) => ExecutePass(m_IndirectGrassRenderer, context));
            }
        }

        [System.Obsolete]
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
            
        }

        [System.Obsolete]
        // Here you can implement the rendering logic.
        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {

            //创建cmd
            CommandBuffer cmd = CommandBufferPool.Get("IndirectGrassCulling");

            // dispatch per visible cell
            // 所有的 dispatch部分交给rendererFeature，以免出现在unknown scope中不方便debug
            // 而且可以精准控制dispatch时机
            // todo:job system
            int dispatchCount = 0;

            for (int i = 0; i < m_IndirectGrassRenderer.m_visibleCellIDList.Count; i++)
            {
                int targetCellFlattenID = m_IndirectGrassRenderer.m_visibleCellIDList[i];
                int memoryOffset = 0;
                for (int j = 0; j < targetCellFlattenID; j++)
                {
                    memoryOffset += m_IndirectGrassRenderer.m_cellPosWSsList[j].Count;
                }
                cmd.SetComputeIntParam(m_IndirectGrassRenderer.cullingComputeShader, "_StartOffset", memoryOffset);//culling read data started at offseted pos, will start from cell's total offset in memory
                int jobLength = m_IndirectGrassRenderer.m_cellPosWSsList[targetCellFlattenID].Count;

                //============================================================================================
                //batch n dispatchs into 1 dispatch, if memory is continuous in m_allInstancesPosWSBuffer
                while ((i < m_IndirectGrassRenderer.m_visibleCellIDList.Count - 1) && //test this first to avoid out of bound access to visibleCellIDList
                        (m_IndirectGrassRenderer.m_visibleCellIDList[i + 1] == m_IndirectGrassRenderer.m_visibleCellIDList[i] + 1))
                {
                    //if memory is continuous, append them together into the same dispatch call
                    jobLength += m_IndirectGrassRenderer.m_cellPosWSsList[m_IndirectGrassRenderer.m_visibleCellIDList[i + 1]].Count;
                    i++;
                }

                //============================================================================================

                if(jobLength > 0){
                    cmd.DispatchCompute(m_IndirectGrassRenderer.cullingComputeShader, 0, Mathf.CeilToInt(jobLength / 64f), 1, 1);
                    dispatchCount++;
                }
            }

            //execute
            context.ExecuteCommandBuffer(cmd);

            //release
            CommandBufferPool.Release(cmd);
        }

        // Cleanup any allocated resources that were created during the execution of this render pass.
        public override void OnCameraCleanup(CommandBuffer cmd)
        {

        }

    }

    // 执行 草的渲染pass
    class IndirectGrassDrawingPass : ScriptableRenderPass
    {
        private IndirectGrassRenderer m_IndirectGrassRenderer;
        private ProfilingSampler m_ProfilingSampler = new ProfilingSampler("IndirectGrassDrawingPass");

        internal bool Setup(ref RenderingData renderingData, IndirectGrassRenderer grassRenderer)
        {
            m_IndirectGrassRenderer = grassRenderer;

            return true;
        }

        private class PassData
        {

        }

        static void ExecutePass(IndirectGrassRenderer indirectGrassRenderer, RasterGraphContext context)
        {
            context.cmd.DrawMeshInstancedIndirect(indirectGrassRenderer.m_grassSetting.grassMesh, 0, indirectGrassRenderer.m_grassSetting.grassMaterial, 0, indirectGrassRenderer.m_argsBuffer);
        }

        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            const string passName = "IndirectGrassDrawingPass";

            // This adds a raster render pass to the graph, specifying the name and the data type that will be passed to the ExecutePass function.
            using (var builder = renderGraph.AddRasterRenderPass<PassData>(passName, out var passData, m_ProfilingSampler))
            {
                UniversalResourceData resourceData = frameData.Get<UniversalResourceData>();

                builder.SetRenderAttachment(resourceData.activeColorTexture, 0);
                builder.SetRenderAttachmentDepth(resourceData.activeDepthTexture);
                builder.AllowPassCulling(false);// 必须的，否则pass被自动剔除了

                builder.SetRenderFunc((PassData data, RasterGraphContext context) => ExecutePass(m_IndirectGrassRenderer, context));
            }
        }

        [System.Obsolete]
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
            
        }

        [System.Obsolete]
        // Here you can implement the rendering logic.
        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            //创建cmd
            CommandBuffer cmd = CommandBufferPool.Get("IndirectGrassRendering");

            cmd.DrawMeshInstancedIndirect(m_IndirectGrassRenderer.m_grassSetting.grassMesh, 0, m_IndirectGrassRenderer.m_grassSetting.grassMaterial, 0, m_IndirectGrassRenderer.m_argsBuffer);

            //execute
            context.ExecuteCommandBuffer(cmd);

            //release
            CommandBufferPool.Release(cmd);
        }

        // Cleanup any allocated resources that were created during the execution of this render pass.
        public override void OnCameraCleanup(CommandBuffer cmd)
        {

        }
    }


    /// <inheritdoc/>
    public override void Create()
    {
        m_HiZBufferGeneratePass = new HiZBufferGeneratePass();
        m_IndirectGrassCullingPass = new IndirectGrassCullingPass();
        m_IndirectGrassDrawingPass = new IndirectGrassDrawingPass();

        // Configures where the render pass should be injected.
        m_HiZBufferGeneratePass.renderPassEvent = RenderPassEvent.AfterRenderingPrePasses + 4;
        m_IndirectGrassCullingPass.renderPassEvent = RenderPassEvent.AfterRenderingPrePasses + 5;
        m_IndirectGrassDrawingPass.renderPassEvent = RenderPassEvent.BeforeRenderingOpaques; // 放在这里防止不透明物overdraw
        
    }

    // 释放资源
    protected override void Dispose(bool disposing)
    {
        m_HiZBufferGeneratePass?.Dispose();
        m_HiZBufferGeneratePass = null;
        m_HiZBufferGeneratePass = null;
        m_HiZBufferGeneratePass = null;
    }

    // Here you can inject one or multiple render passes in the renderer.
    // This method is called when setting up the renderer once per-camera.
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if((renderingData.cameraData.camera.name == "Camera3D" || renderingData.cameraData.camera.name == "SceneCamera" ) && Application.isPlaying){
            IndirectGrassRenderer grassRenderer = GameObject.FindFirstObjectByType<IndirectGrassRenderer>();
            if(grassRenderer != null && grassRenderer.enabled){
                m_IndirectGrassCullingPass.Setup(ref renderingData, grassRenderer);
                m_IndirectGrassDrawingPass.Setup(ref renderingData, grassRenderer);
                // renderer.EnqueuePass(m_HiZBufferGeneratePass);
                renderer.EnqueuePass(m_IndirectGrassCullingPass);
                renderer.EnqueuePass(m_IndirectGrassDrawingPass);
            }
            
        }
            
    }
}


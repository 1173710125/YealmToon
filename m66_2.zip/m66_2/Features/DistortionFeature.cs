using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Experimental.Rendering;

// 扰动特效feature
// 首先需要绘制到一张RG颜色的通道mask上
// 在最终步骤 与Bloom_texture 一同影响最终结果
public class DistortionFeature : ScriptableRendererFeature
{
    class DistortionRenderPass : ScriptableRenderPass
    {
        private RTHandle distortionTargetHandle;
        private ShaderTagId m_shaderTagId;
        private GlobalParameterSettings m_globalSettings;
        private FilteringSettings m_filteringSettings;

        static readonly int s_distortMask = Shader.PropertyToID("_DistortMask");

        private class PassData
        {
            public RendererListHandle RendererListHandle;
        }

        static void ExecutePass(PassData data, UnsafeGraphContext context)
        {

        }

        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            const string passName = "DistortMaskPass";

            // This adds a raster render pass to the graph, specifying the name and the data type that will be passed to the ExecutePass function.
            using (var builder = renderGraph.AddRasterRenderPass<PassData>(passName, out var passData))
            {

                // Access the relevant frame data from the Universal Render Pipeline
                UniversalRenderingData universalRenderingData = frameData.Get<UniversalRenderingData>();
                UniversalCameraData cameraData = frameData.Get<UniversalCameraData>();
                UniversalLightData lightData = frameData.Get<UniversalLightData>();

                var sortFlags = SortingCriteria.CommonOpaque;
                DrawingSettings drawSettings =
RenderingUtils.CreateDrawingSettings(m_shaderTagId, universalRenderingData, cameraData, lightData, sortFlags);

                var param =
new RendererListParams(universalRenderingData.cullResults, drawSettings, m_filteringSettings);
                passData.RendererListHandle = renderGraph.CreateRendererList(param);
                
                RenderTextureDescriptor desc = new RenderTextureDescriptor(
                    m_globalSettings.width.value / 5,
                    m_globalSettings.height.value / 5);
                desc.colorFormat = RenderTextureFormat.RG16;
                TextureHandle destination =
UniversalRenderer.CreateRenderGraphTexture(renderGraph, desc, "_DistortMaskTarget", false);
                
                builder.UseRendererList(passData.RendererListHandle);
                builder.SetRenderAttachment(destination, 0);
                builder.AllowPassCulling(false);
                builder.SetRenderFunc((PassData data, RasterGraphContext context) =>
                {
                    context.cmd.ClearRenderTarget(RTClearFlags.All, Color.gray, 1, 0);
                    context.cmd.DrawRendererList(data.RendererListHandle); 
                });
                builder.SetGlobalTextureAfterPass(destination, s_distortMask);
            }
        }

        internal bool Setup(ref RenderingData renderingData)
        {
            m_globalSettings = VolumeManager.instance.stack.GetComponent<GlobalParameterSettings>();
        
            if(m_globalSettings == null) return false;

            m_filteringSettings = new FilteringSettings(RenderQueueRange.all);
            m_shaderTagId = new ShaderTagId("DistortMask");

            return true;
        }

        // This method is called before executing the render pass.
        // It can be used to configure render targets and their clear state. Also to create temporary render target textures.
        // When empty this render pass will render to the active camera render target.
        // You should never call CommandBuffer.SetRenderTarget. Instead call <c>ConfigureTarget</c> and <c>ConfigureClear</c>.
        // The render pipeline will ensure target setup and clearing happens in a performant manner.
        [System.Obsolete]
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
        }

        [System.Obsolete]
        public override void Configure(CommandBuffer cmd, RenderTextureDescriptor cameraTextureDescriptor)
        {
            // 创建 RTHandle
            RenderTextureDescriptor descriptor = new RenderTextureDescriptor(m_globalSettings.width.value / 5, m_globalSettings.height.value / 5, RenderTextureFormat.RG16, 0);
            descriptor.sRGB = false;
            descriptor.useMipMap = false;
            descriptor.autoGenerateMips = false;
            RenderingUtils.ReAllocateIfNeeded(ref distortionTargetHandle, descriptor, FilterMode.Bilinear, TextureWrapMode.Clamp, name: "_DistortionRenderTexture");
            ConfigureTarget(distortionTargetHandle);
            ConfigureClear(ClearFlag.Color, Color.clear); // Clear with the required flags
        }

        // Here you can implement the rendering logic.
        // Use <c>ScriptableRenderContext</c> to issue drawing commands or execute command buffers
        // https://docs.unity3d.com/ScriptReference/Rendering.ScriptableRenderContext.html
        // You don't have to call ScriptableRenderContext.submit, the render pipeline will call it at specific points in the pipeline.
        [System.Obsolete]
        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            CommandBuffer cmd = CommandBufferPool.Get("distorion mask rendering");

            using (new ProfilingScope(cmd, new ProfilingSampler("distorion mask rendering Profiling"))){
                // Set up drawing settings with the specific shader pass name
                var drawingSettings = CreateDrawingSettings(m_shaderTagId, ref renderingData, SortingCriteria.CommonOpaque);
                var filteringSettings = new FilteringSettings(RenderQueueRange.opaque);

                
                // Render objects with the specified light mode
                context.DrawRenderers(renderingData.cullResults, ref drawingSettings, ref filteringSettings);

                // 开启全屏扰动
                cmd.SetGlobalTexture(s_distortMask, distortionTargetHandle);

            }

            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }

        // Cleanup any allocated resources that were created during the execution of this render pass.
        public override void OnCameraCleanup(CommandBuffer cmd)
        {
            
        }

        public void ReleaseTargets(){
            distortionTargetHandle?.Release();
        }
    }

    DistortionRenderPass m_distortionRenderPass;

    /// <inheritdoc/>
    public override void Create()
    {
        m_distortionRenderPass = new DistortionRenderPass();

        // Configures where the render pass should be injected.
        m_distortionRenderPass.renderPassEvent = RenderPassEvent.AfterRenderingPrePasses + 9;
    }

    // Here you can inject one or multiple render passes in the renderer.
    // This method is called when setting up the renderer once per-camera.
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if(m_distortionRenderPass.Setup(ref renderingData)){
            renderer.EnqueuePass(m_distortionRenderPass);
        }
    
    }

    // 释放资源
    protected override void Dispose(bool disposing)
    {
        m_distortionRenderPass.ReleaseTargets();
    }
}


